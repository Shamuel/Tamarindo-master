﻿Public Class MenúPrincipal

    Private Sub MenúprincipalSystemAdmin_Load(sender As Object, e As EventArgs)

    End Sub



    Private Sub ExpedientesDeEmpleadosToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExpedientesDeEmpleadosToolStripMenuItem.Click
        BuscarExpedienteEmpleado.Show()

    End Sub

    Private Sub ExpedientesDeCandidatosToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExpedientesDeCandidatosToolStripMenuItem.Click
        BuscarExpedienteCandidato.Show()
    End Sub

    Private Sub SalirToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles SalirToolStripMenuItem1.Click
        Me.Close()
    End Sub

    Private Sub ExpedientesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExpedientesToolStripMenuItem.Click

    End Sub

    Private Sub MenuStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub

    Private Sub MiExpedienteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MiExpedienteToolStripMenuItem.Click
        ExpedienteDeEmpleado.Show()
    End Sub

    Private Sub MenúprincipalSystemAdmin_Load_1(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim IDdeLogin As String = Login.Usuario.Text

        'administrador
        If (TipoUsuario(IDdeLogin)) = 1 Then 'FK_TipoUsuario_103 = administrador
            AnalitycsToolStripMenuItem.Visible = True
            VerReportesToolStripMenuItem.Visible = True
            PruebasToolStripMenuItem.Visible = True

            AgendarPruebaToolStripMenuItem.Visible = True
            ExpedientesToolStripMenuItem.Visible = True
            ExpedientesDeCandidatosToolStripMenuItem.Visible = True
            ExpedientesDeEmpleadosToolStripMenuItem.Visible = True
            MiExpedienteToolStripMenuItem.Visible = True
            RegistroToolStripMenuItem.Visible = True
            RegistroDeCandidatosToolStripMenuItem.Visible = True
            RegistroDeEmpleadosToolStripMenuItem.Visible = True
        End If
        'reclutador
        If (TipoUsuario(IDdeLogin)) = 2 Then   'FK_TipoUsuario_103 = reclutador
            AnalitycsToolStripMenuItem.Visible = False
            VerReportesToolStripMenuItem.Visible = False
            PruebasToolStripMenuItem.Visible = True
            AgendarPruebaToolStripMenuItem.Visible = True
            ExpedientesToolStripMenuItem.Visible = True
            ExpedientesDeCandidatosToolStripMenuItem.Visible = True
            ExpedientesDeEmpleadosToolStripMenuItem.Visible = False
            MiExpedienteToolStripMenuItem.Visible = True
            RegistroToolStripMenuItem.Visible = True
            RegistroDeCandidatosToolStripMenuItem.Visible = True
            RegistroDeEmpleadosToolStripMenuItem.Visible = False
        End If
        'QA
        If (TipoUsuario(IDdeLogin)) = 3 Then   'FK_TipoUsuario_103 = QA
            AnalitycsToolStripMenuItem.Visible = False
            VerReportesToolStripMenuItem.Visible = False
            PruebasToolStripMenuItem.Visible = True
            AgendarPruebaToolStripMenuItem.Visible = True
            ExpedientesToolStripMenuItem.Visible = True
            ExpedientesDeCandidatosToolStripMenuItem.Visible = False
            ExpedientesDeEmpleadosToolStripMenuItem.Visible = True
            MiExpedienteToolStripMenuItem.Visible = True
            RegistroToolStripMenuItem.Visible = True
            RegistroDeCandidatosToolStripMenuItem.Visible = False
            RegistroDeEmpleadosToolStripMenuItem.Visible = True
        End If
        'empleado
        If (TipoUsuario(IDdeLogin)) = 4 Then   'FK_TipoUsuario_103 = empleado
            AnalitycsToolStripMenuItem.Visible = False
            VerReportesToolStripMenuItem.Visible = False
            PruebasToolStripMenuItem.Visible = True

            AgendarPruebaToolStripMenuItem.Visible = False
            ExpedientesToolStripMenuItem.Visible = True
            ExpedientesDeCandidatosToolStripMenuItem.Visible = False
            ExpedientesDeEmpleadosToolStripMenuItem.Visible = False
            MiExpedienteToolStripMenuItem.Visible = True
            RegistroToolStripMenuItem.Visible = False
            RegistroDeCandidatosToolStripMenuItem.Visible = False
            RegistroDeEmpleadosToolStripMenuItem.Visible = False
        End If
        'gerente
        If (TipoUsuario(IDdeLogin)) = 5 Then   'FK_TipoUsuario_103 = gerente
            AnalitycsToolStripMenuItem.Visible = True
            VerReportesToolStripMenuItem.Visible = True
            PruebasToolStripMenuItem.Visible = False
            AgendarPruebaToolStripMenuItem.Visible = False
            ExpedientesToolStripMenuItem.Visible = True
            ExpedientesDeCandidatosToolStripMenuItem.Visible = False
            ExpedientesDeEmpleadosToolStripMenuItem.Visible = False
            MiExpedienteToolStripMenuItem.Visible = True
            RegistroToolStripMenuItem.Visible = False
            RegistroDeCandidatosToolStripMenuItem.Visible = False
            RegistroDeEmpleadosToolStripMenuItem.Visible = False

        End If
    End Sub

    Private Sub RegistroDeCandidatosToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RegistroDeCandidatosToolStripMenuItem.Click
        RegistroCandidato.Show()
    End Sub

    Private Sub RegistroDeEmpleadosToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RegistroDeEmpleadosToolStripMenuItem.Click
        RegistroEmpleado.Show()
    End Sub

    Private Sub VerReportesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VerReportesToolStripMenuItem.Click
        Metricas.Show()

    End Sub

    Private Sub AgendarPruebaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AgendarPruebaToolStripMenuItem.Click
        Ver_fecha_de_pruebas.Show()

    End Sub
End Class