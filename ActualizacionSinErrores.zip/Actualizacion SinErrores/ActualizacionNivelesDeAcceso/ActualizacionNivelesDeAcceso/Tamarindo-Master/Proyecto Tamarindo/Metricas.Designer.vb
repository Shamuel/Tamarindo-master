﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Metricas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Metricas))
        Dim ChartArea2 As System.Windows.Forms.DataVisualization.Charting.ChartArea = New System.Windows.Forms.DataVisualization.Charting.ChartArea()
        Dim Legend2 As System.Windows.Forms.DataVisualization.Charting.Legend = New System.Windows.Forms.DataVisualization.Charting.Legend()
        Dim Series2 As System.Windows.Forms.DataVisualization.Charting.Series = New System.Windows.Forms.DataVisualization.Charting.Series()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cedulaEmpleado = New System.Windows.Forms.Label()
        Me.txtCedula = New System.Windows.Forms.TextBox()
        Me.busqueda = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Chart1 = New System.Windows.Forms.DataVisualization.Charting.Chart()
        Me.salir = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(24, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(641, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Para realizar una búsqueda ingrese la cédula del Empleado"
        '
        'cedulaEmpleado
        '
        Me.cedulaEmpleado.AutoSize = True
        Me.cedulaEmpleado.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cedulaEmpleado.Location = New System.Drawing.Point(62, 126)
        Me.cedulaEmpleado.Name = "cedulaEmpleado"
        Me.cedulaEmpleado.Size = New System.Drawing.Size(75, 24)
        Me.cedulaEmpleado.TabIndex = 0
        Me.cedulaEmpleado.Text = "Cédula:"
        '
        'txtCedula
        '
        Me.txtCedula.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCedula.Location = New System.Drawing.Point(179, 126)
        Me.txtCedula.Name = "txtCedula"
        Me.txtCedula.Size = New System.Drawing.Size(231, 29)
        Me.txtCedula.TabIndex = 3
        '
        'busqueda
        '
        Me.busqueda.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.busqueda.Image = CType(resources.GetObject("busqueda.Image"), System.Drawing.Image)
        Me.busqueda.Location = New System.Drawing.Point(434, 126)
        Me.busqueda.Name = "busqueda"
        Me.busqueda.Size = New System.Drawing.Size(86, 73)
        Me.busqueda.TabIndex = 4
        Me.busqueda.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(52, 213)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(549, 147)
        Me.DataGridView1.TabIndex = 5
        '
        'Chart1
        '
        ChartArea2.Name = "ChartArea1"
        Me.Chart1.ChartAreas.Add(ChartArea2)
        Legend2.Name = "Legend1"
        Me.Chart1.Legends.Add(Legend2)
        Me.Chart1.Location = New System.Drawing.Point(631, 138)
        Me.Chart1.Name = "Chart1"
        Series2.ChartArea = "ChartArea1"
        Series2.Legend = "Legend1"
        Series2.Name = "Series1"
        Series2.YValuesPerPoint = 2
        Me.Chart1.Series.Add(Series2)
        Me.Chart1.Size = New System.Drawing.Size(317, 222)
        Me.Chart1.TabIndex = 6
        Me.Chart1.Text = "Chart1"
        '
        'salir
        '
        Me.salir.BackgroundImage = CType(resources.GetObject("salir.BackgroundImage"), System.Drawing.Image)
        Me.salir.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.salir.Location = New System.Drawing.Point(532, 126)
        Me.salir.Name = "salir"
        Me.salir.Size = New System.Drawing.Size(82, 73)
        Me.salir.TabIndex = 7
        Me.salir.UseVisualStyleBackColor = True
        '
        'Metricas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(960, 389)
        Me.Controls.Add(Me.salir)
        Me.Controls.Add(Me.busqueda)
        Me.Controls.Add(Me.txtCedula)
        Me.Controls.Add(Me.cedulaEmpleado)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Chart1)
        Me.Name = "Metricas"
        Me.Text = "Métricas"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Chart1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents cedulaEmpleado As Label
    Friend WithEvents txtCedula As TextBox
    Friend WithEvents busqueda As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Chart1 As DataVisualization.Charting.Chart
    Friend WithEvents salir As Button
End Class
