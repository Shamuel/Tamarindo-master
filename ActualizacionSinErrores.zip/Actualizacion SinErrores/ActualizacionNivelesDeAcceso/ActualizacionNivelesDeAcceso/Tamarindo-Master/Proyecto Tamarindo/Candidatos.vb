﻿Public Class RegistroCandidato

    Private Sub RegistroCandidato_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'conexion.Open()
        Modificar.Enabled = False
        Guardar.Enabled = False
        Eliminar.Enabled = False
        ModificarDatos.Visible = False
        EliminarSeguro.Visible = False
        Cancelar.Visible = False
        EliminarSeguro.Visible = False
        Cancelar1.Visible = False
    End Sub

    Private Sub Nuevo_Click(sender As Object, e As EventArgs) Handles Nuevo.Click
        Modificar.Enabled = True
        Guardar.Enabled = True
        Eliminar.Enabled = True


    End Sub

    Private Sub Guardar_Click(sender As Object, e As EventArgs) Handles Guardar.Click
        Dim Agregar As String = "Insert into TBL_Persona_500 values" & "('" & Cedula.Text & "','" & TipoID.Text & "','" & Nombre.Text & "','" & PrimerApellido.Text & "','" & SegundoApellido.Text & "','" & Fecha.Value.Date.ToString(" yyyy-MM-dd hh:mm") & "','" & Telefono.Text & "','" & Correo.Text & "')"


        If Nombre.Text <> "" And Cedula.Text <> "" And PrimerApellido.Text <> "" And Correo.Text <> "" And SegundoApellido.Text <> "" Then

            If (TodoLaConexion.InsertarPersona(Agregar)) Then
                MsgBox("Datos Guardados Correctamente")
            Else
                MsgBox("Error al guardar los datos")
            End If

            Cedula.Clear()
            Nombre.Clear()
            Correo.Clear()
            Telefono.Clear()
            PrimerApellido.Clear()
            SegundoApellido.Clear()

        Else
            MsgBox("Escriba en Cada Campo")
        End If
    End Sub

    Private Sub Modificar_Click(sender As Object, e As EventArgs) Handles Modificar.Click
        TipoID.Enabled = False
        Fecha.Enabled = False
        ModificarDatos.Visible = True
        Cancelar1.Visible = True
    End Sub

    Private Sub ModificarDatos_Click(sender As Object, e As EventArgs) Handles ModificarDatos.Click
        'Advertencia
        Dim Mensaje As MsgBoxResult = MsgBox("Esta Seguro que desea Eliminar a este Candidato?", MsgBoxStyle.YesNo)

        If Mensaje = MsgBoxResult.Yes Then
            Dim modificar As String = "Update TBL_Persona_500 Set CP_Nombre = '" & Nombre.Text & "'," & "CP_Apellido1 = '" & PrimerApellido.Text & "'," & "CP_Apellido2 = '" & SegundoApellido.Text & "'," & "CP_Telefono1 = '" & Telefono.Text & "'," & "CP_Correo = '" & Correo.Text & "'" & "where PK_ID = '" & Cedula.Text & "';"

            If Nombre.Text <> "" And Cedula.Text <> "" And PrimerApellido.Text <> "" And Correo.Text <> "" And SegundoApellido.Text <> "" Then

                If (TodoLaConexion.InsertarPersona(modificar)) Then
                    MsgBox("Datos Modificados Correctamente")
                Else
                    MsgBox("Error al Modificar los datos")
                End If
                ModificarDatos.Visible = False
                Cancelar1.Visible = False
                Cedula.Clear()
                Nombre.Clear()
                Correo.Clear()
                Telefono.Clear()
                PrimerApellido.Clear()
                SegundoApellido.Clear()

            Else
                MsgBox("Escriba en Cada Campo")
            End If
        Else

        End If

    End Sub

    Private Sub Eliminar_Click(sender As Object, e As EventArgs) Handles Eliminar.Click
        EliminarSeguro.Visible = True
        Nombre.Visible = False
        PrimerApellido.Visible = False
        SegundoApellido.Visible = False
        Correo.Visible = False
        Telefono.Visible = False
        TipoID.Visible = False
        Cancelar.Visible = True
        EliminarSeguro.Visible = True

    End Sub

    Private Sub EliminarSeguro_Click(sender As Object, e As EventArgs) Handles EliminarSeguro.Click
        'Advertencia
        Dim Mensaje As MsgBoxResult = MsgBox("Esta Seguro que desea Eliminar a este Candidato?", MsgBoxStyle.YesNo)

        If Mensaje = MsgBoxResult.Yes Then
            Dim Eliminar As String = "Delete from TBL_Persona_500 where PK_ID = '" & Cedula.Text & "';"

            If Cedula.Text <> "" Then

                If (TodoLaConexion.InsertarPersona(Eliminar)) Then
                    MsgBox("Datos Eliminados Correctamente")
                Else
                    MsgBox("Error al Eliminar los datos")
                End If

                Cedula.Clear()
                Nombre.Visible = True
                Correo.Visible = True
                Telefono.Visible = True
                PrimerApellido.Visible = True
                SegundoApellido.Visible = True
                Fecha.Visible = True
                TipoID.Visible = True
                Cancelar.Visible = False
                EliminarSeguro.Visible = False
            Else
                MsgBox("Escriba en Cada Campo")
                Cedula.Clear()
                Nombre.Visible = True
                Correo.Visible = True
                Telefono.Visible = True
                PrimerApellido.Visible = True
                SegundoApellido.Visible = True
                Fecha.Visible = True
                TipoID.Visible = True
                Cancelar.Visible = False
                EliminarSeguro.Visible = False
            End If
        Else

        End If
    End Sub

    Private Sub Cancelar_Click(sender As Object, e As EventArgs) Handles Cancelar.Click
        Cedula.Clear()
        Nombre.Visible = True
        Correo.Visible = True
        Telefono.Visible = True
        PrimerApellido.Visible = True
        SegundoApellido.Visible = True
        Fecha.Visible = True
        TipoID.Visible = True
        Cancelar.Visible = False
        EliminarSeguro.Visible = False
    End Sub

    Private Sub Cancelar1_Click(sender As Object, e As EventArgs) Handles Cancelar1.Click
        ModificarDatos.Visible = False
        Cancelar1.Visible = False
        Fecha.Enabled = True
        TipoID.Enabled = True
    End Sub

    Private Sub Salir_Click(sender As Object, e As EventArgs) Handles Salir.Click
        Me.Close()
    End Sub
End Class
