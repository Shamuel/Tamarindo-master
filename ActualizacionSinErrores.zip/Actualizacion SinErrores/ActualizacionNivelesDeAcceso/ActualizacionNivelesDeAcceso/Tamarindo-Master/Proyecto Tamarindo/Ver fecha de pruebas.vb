﻿Public Class Ver_fecha_de_pruebas
    Private Sub Ver_fecha_de_pruebas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Calificacion.Enabled = False
        Cancelar.Visible = False
    End Sub

    Private Sub Anadir_Click(sender As Object, e As EventArgs) Handles Anadir.Click
        Dim Anadir As String = "Insert into TBL_RegistroDePruebas_501 values (" & 1 & "," & Cedula.Text & "," & TipoPrueba.Text & ",'" & Fechas.Value.Date.ToString(" yyyy-MM-dd hh:mm") & "','" & Fechas.Value.Date.ToString(" yyyy-MM-dd hh:mm") & "'," & 0 & "," & 0 & ");"
        If Cedula.Text <> "" And TipoPrueba.Text <> "" Then
            Insertar(Anadir)
            MsgBox("Datos Guardados Correctamente")
        Else
            MsgBox("Escriba en cada Campo")
        End If
    End Sub

    Private Sub Modificar_Click(sender As Object, e As EventArgs) Handles Modificar.Click
        Calificacion.Enabled = True
        Dim modificar As String = "Update TBL_RegistroDePruebas_501 SET CP_FechaRealizacion = '" & Fechas.Value.Date.ToString(" yyyy-MM-dd hh:mm") & "', CP_Calificacion = " & Calificacion.Text & "where FK_Id_500= '" & Cedula.Text & "';"
        If Cedula.Text <> "" And Calificacion.Text <> "" Then
            Insertar(modificar)
            MsgBox("Datos Modificados Correctamente")
        Else
            MsgBox("Escriba en cada Campo")
        End If
    End Sub

    Private Sub Eliminar_Click(sender As Object, e As EventArgs) Handles Eliminar.Click
        Calificacion.Enabled = False
        TipoPrueba.Enabled = False
        Cancelar.Visible = True

        Dim eliminar As String = "Delete from TBL_RegistroDePruebas_501 where FK_Id_500 = '" & Cedula.Text & "';"
        If Cedula.Text <> "" Then
            Insertar(eliminar)
            MsgBox("Datos Eliminados Correctamente")
        Else
            MsgBox("Escriba la Cedula")
        End If
    End Sub

    Private Sub Cancelar_Click(sender As Object, e As EventArgs) Handles Cancelar.Click
        Cancelar.Visible = False
        Calificacion.Enabled = True
        TipoPrueba.Enabled = True
    End Sub

    Private Sub Salir_Click(sender As Object, e As EventArgs) Handles Salir.Click
        Me.Close()
    End Sub
End Class