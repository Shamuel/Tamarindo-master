﻿Public Class Menu_principal_gerente
    Private Sub ButtonReportes_Click(sender As Object, e As EventArgs) Handles ButtonReportes.Click

    End Sub
End Class