﻿Public Class Ingresar_codigo_del_empleado
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Ver_reporte.Show()


    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form1.Show()

    End Sub
End Class