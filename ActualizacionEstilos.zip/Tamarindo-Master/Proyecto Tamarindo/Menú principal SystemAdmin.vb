﻿Public Class MenúprincipalSystemAdmin
    Private Sub ButtonPruebas_Click(sender As Object, e As EventArgs) Handles ButtonPruebas.Click

    End Sub

    Private Sub ButtonExpedientes_Click(sender As Object, e As EventArgs)
        RegistroCandidato.Show()
    End Sub

    Private Sub ButtonAnalitycs_Click(sender As Object, e As EventArgs) Handles ButtonAnalitycs.Click

    End Sub

    Private Sub MenúprincipalSystemAdmin_Load(sender As Object, e As EventArgs)

    End Sub

    Private Sub ButtonExpedientes_Click_2(sender As Object, e As EventArgs) Handles ButtonExpedientes.Click
        ExpedientesGeneral.Show()
    End Sub
End Class