﻿Public Class RegistroEmpleado
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        'TODOS ESTOS COMANDOS REALIZAN CONEXION MANUAL A BASE DE DATOS Y BORRAN UN REGISTRO
        'ELIMINA
        '1- Definir nombre del servidor y la base de datos para conexion
        Dim servidor_datos As String
        servidor_datos = "Data Source=LAB4-22;Initial Catalog=VENTAS;Integrated Security=SSPI;"

        '2- Definir una conexion para la base de datos
        Dim conexion As New SqlClient.SqlConnection(servidor_datos)
        conexion.ConnectionString = servidor_datos

        '3- Ejecuta un comando para insertar datos en la base de datos
        Dim instruccionSQL As String
        Try
            '3.1 Define comando SQL
            instruccionSQL = "DELETE FROM CLIENTES WHERE CEDULA=" & Me.TextBox1.Text

            '3.2 Define conexion y aplica comando
            Dim comando As New SqlClient.SqlCommand(instruccionSQL, conexion)

            '3.3 Abre la conexion a la base de datos
            conexion.Open()

            '3.4 Ejecuta el comando para sentencias SQL
            comando.ExecuteNonQuery()

            '3.5 Refresca el datagridview
            TextBox1.Refresh()
            TextBox2.Refresh()
            TextBox3.Refresh()
            TextBox4.Refresh()
            ComboBox1.Refresh()

            MessageBox.Show("DATOS ACTUALIZADOS!", "MENSAJE DEL SISTEMA",
       MessageBoxButtons.OK, MessageBoxIcon.Asterisk)

        Catch mensajeERROR As Exception
            MsgBox(mensajeERROR.Message)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.TextBox1.Enabled = True
        Me.TextBox2.Enabled = True
        Me.TextBox3.Enabled = True
        Me.TextBox4.Enabled = True
        Me.ComboBox1.Enabled = True
        Me.Button3.Enabled = True
        Me.Button2.Enabled = True
        Me.Button4.Enabled = True
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.TextBox1.Enabled = True
        Me.TextBox2.Enabled = True
        Me.TextBox3.Enabled = True
        Me.TextBox4.Enabled = True
        Me.ComboBox1.Enabled = True
        TextBox1.Focus()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        'Define conectividad a base de datos

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        BuscarExpedienteEmpleado.Show()
    End Sub

    Private Sub RegistroEmpleado_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'VENTASDataSet.CLIENTES' Puede moverla o quitarla según sea necesario.
        Me.TextBox1.Enabled = False
        Me.TextBox2.Enabled = False
        Me.TextBox3.Enabled = False
        Me.TextBox4.Enabled = False
        Me.ComboBox1.Enabled = False
        Me.Button3.Enabled = False
        Me.Button2.Enabled = False
        Me.Button4.Enabled = False
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Me.Close()
    End Sub
End Class