﻿Imports System.Data.SqlClient

Public Class Ver_fecha_de_pruebas
    Private Sub Ver_fecha_de_pruebas_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Calificacion.Enabled = False
        TipoPrueba.Enabled = False
        Cedula.Enabled = False
        Enviar.Enabled = False
        tooltip()

        Dim sqlquery As String = "SELECT CP_NombrePrueba FROM TBL_TiposDePrueba_501"
        Using strCombBx As SqlCommand = New SqlCommand(sqlquery, conexion)

            'conexion.Open()
            Dim reader As SqlDataReader = strCombBx.ExecuteReader
            Dim dtCB As New DataTable

            dtCB.Load(reader)
            TipoPrueba.ValueMember = "Tipo de Métrica"
            TipoPrueba.DisplayMember = "CP_NombrePrueba"
            TipoPrueba.DataSource = dtCB

            'conexion.Close()

        End Using

    End Sub

    Sub tooltip()
        ToolTip1.SetToolTip(Calificacion, "Ingrese una nota menor a 100")
    End Sub


    Private Sub Salir_Click(sender As Object, e As EventArgs) Handles Salir.Click
        Me.Close()
    End Sub

    Private Sub Enviar_Click(sender As Object, e As EventArgs) Handles Enviar.Click
        If Anadir.Checked = True Then
            Dim Anadir As String = "Insert into TBL_RegistroDePruebas_501 values ('" & Cedula.Text & "' ," & (TipoPrueba.SelectedIndex + 1) & ", '" & Fechas.Value.Date.ToString("yyyy-MM-dd hh:mm") & "', '" & Fechas.Value.Date.ToString("yyyy-MM-dd hh:mm") & "', " & 0 & "," & 0 & ")"
            If Cedula.Text <> "" And TipoPrueba.Text <> "" Then
                Insertar(Anadir)
                MsgBox("Datos Guardados Correctamente")
            Else
                MsgBox("Escriba en cada Campo")
            End If
        End If

        If Modificar.Checked = True Then
            Dim Scriptmodificar As String = "Update TBL_RegistroDePruebas_501 SET CP_FechaRealizacion = '" & Fechas.Value.Date.ToString(" yyyy-MM-dd hh:mm") & "', CP_Calificacion = " & Calificacion.Text & "where FK_Id_500= '" & Cedula.Text & "';"
            If Cedula.Text <> "" And Calificacion.Text <> "" Then
                Insertar(Scriptmodificar)
                MsgBox("Datos Modificados Correctamente")
            Else
                MsgBox("Escriba en cada Campo")
            End If
        End If


        'If Cedula.Text <> "" Then
        '    Dim eliminar As String = "Delete from TBL_RegistroDePruebas_501 where FK_Id_500 = '" & Cedula.Text & "';"
        '    Insertar(Eliminar)
        '    MsgBox("Datos Eliminados Correctamente")
        'Else
        '    MsgBox("Escriba la Cedula")
        'End If

    End Sub

    Private Sub Anadir_CheckedChanged(sender As Object, e As EventArgs) Handles Anadir.CheckedChanged
        Cedula.Enabled = True
        TipoPrueba.Enabled = True
        Enviar.Enabled = True
    End Sub

    Private Sub Modificar_CheckedChanged(sender As Object, e As EventArgs) Handles Modificar.CheckedChanged
        Cedula.Enabled = True
        TipoPrueba.Enabled = True
        Enviar.Enabled = True
        Calificacion.Enabled = True
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Try
            '4- Crear adaptador para llenar el dataset  
            Dim adaptador As SqlClient.SqlDataAdapter
            '5- Definir el dataset
            Dim set_de_datos As New DataSet()
            '6- Definir la variable para la instruccion SQL
            Dim instruccionSQL As String
            instruccionSQL = "SELECT * FROM TBL_RegistroDePruebas_501"

            '7- Cargar el datagridview
            DataGridView1.DataSource = ""
            adaptador = New SqlClient.SqlDataAdapter(instruccionSQL, conexion)
            adaptador.Fill(set_de_datos, "TBL_RegistroDePruebas_501")
            DataGridView1.DataSource = set_de_datos.Tables("TBL_RegistroDePruebas_501")
            DataGridView1.Columns(0).HeaderCell.Value = "Consecutivo"
            DataGridView1.Columns(1).HeaderCell.Value = "Identificación"
            DataGridView1.Columns(2).HeaderCell.Value = "Tipo de Prueba"
            DataGridView1.Columns(3).HeaderCell.Value = "Fecha de Asignación"
            DataGridView1.Columns(4).HeaderCell.Value = "Fecha de Realización"
            DataGridView1.Columns(5).HeaderCell.Value = "¿Prueba realizada?"
            DataGridView1.Columns(6).HeaderCell.Value = "Calificación"



            '8- Enviar mensaje si encontr� o no encontro datos
            Me.Label2.Text = DataGridView1.Rows.Count - 1
            If DataGridView1.Rows.Count > 1 Then
                'MessageBox.Show("LO ENCONTRO!", "MENSAJE DEL SISTEMA",
                'MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            Else
                MessageBox.Show("NO HAY DATOS PARA MOSTRAR!", "MENSAJE DEL SISTEMA",
           MessageBoxButtons.OK, MessageBoxIcon.Asterisk)

            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
        'conexion.Close()
    End Sub
End Class