﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class MenúPrincipal
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MenúPrincipal))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.RegistroToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RegistroDeCandidatosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RegistroDeEmpleadosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExpedientesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExpedientesDeEmpleadosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExpedientesDeCandidatosToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MiExpedienteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PruebasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AgendarPruebaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MisPruebasToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AnalitycsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VerReportesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AgregarTipoDeMétricaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalirToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.LabelMenu = New System.Windows.Forms.Label()
        Me.CrearNuevoTipoDePruebaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CambiarTipoDeUsuarioToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RegistroToolStripMenuItem, Me.ExpedientesToolStripMenuItem, Me.PruebasToolStripMenuItem, Me.AnalitycsToolStripMenuItem, Me.SalirToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(7, 3, 0, 3)
        Me.MenuStrip1.Size = New System.Drawing.Size(615, 34)
        Me.MenuStrip1.TabIndex = 5
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'RegistroToolStripMenuItem
        '
        Me.RegistroToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RegistroDeCandidatosToolStripMenuItem, Me.RegistroDeEmpleadosToolStripMenuItem})
        Me.RegistroToolStripMenuItem.Name = "RegistroToolStripMenuItem"
        Me.RegistroToolStripMenuItem.Size = New System.Drawing.Size(99, 28)
        Me.RegistroToolStripMenuItem.Text = "Registro"
        '
        'RegistroDeCandidatosToolStripMenuItem
        '
        Me.RegistroDeCandidatosToolStripMenuItem.Name = "RegistroDeCandidatosToolStripMenuItem"
        Me.RegistroDeCandidatosToolStripMenuItem.Size = New System.Drawing.Size(185, 28)
        Me.RegistroDeCandidatosToolStripMenuItem.Text = "Candidatos"
        '
        'RegistroDeEmpleadosToolStripMenuItem
        '
        Me.RegistroDeEmpleadosToolStripMenuItem.Name = "RegistroDeEmpleadosToolStripMenuItem"
        Me.RegistroDeEmpleadosToolStripMenuItem.Size = New System.Drawing.Size(185, 28)
        Me.RegistroDeEmpleadosToolStripMenuItem.Text = "Empleados"
        '
        'ExpedientesToolStripMenuItem
        '
        Me.ExpedientesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExpedientesDeEmpleadosToolStripMenuItem, Me.ExpedientesDeCandidatosToolStripMenuItem, Me.MiExpedienteToolStripMenuItem, Me.CambiarTipoDeUsuarioToolStripMenuItem})
        Me.ExpedientesToolStripMenuItem.Name = "ExpedientesToolStripMenuItem"
        Me.ExpedientesToolStripMenuItem.Size = New System.Drawing.Size(139, 28)
        Me.ExpedientesToolStripMenuItem.Text = "Expedientes"
        '
        'ExpedientesDeEmpleadosToolStripMenuItem
        '
        Me.ExpedientesDeEmpleadosToolStripMenuItem.Name = "ExpedientesDeEmpleadosToolStripMenuItem"
        Me.ExpedientesDeEmpleadosToolStripMenuItem.Size = New System.Drawing.Size(336, 28)
        Me.ExpedientesDeEmpleadosToolStripMenuItem.Text = "Expedientes de empleados"
        '
        'ExpedientesDeCandidatosToolStripMenuItem
        '
        Me.ExpedientesDeCandidatosToolStripMenuItem.Name = "ExpedientesDeCandidatosToolStripMenuItem"
        Me.ExpedientesDeCandidatosToolStripMenuItem.Size = New System.Drawing.Size(336, 28)
        Me.ExpedientesDeCandidatosToolStripMenuItem.Text = "Expedientes de candidatos"
        '
        'MiExpedienteToolStripMenuItem
        '
        Me.MiExpedienteToolStripMenuItem.Name = "MiExpedienteToolStripMenuItem"
        Me.MiExpedienteToolStripMenuItem.Size = New System.Drawing.Size(336, 28)
        Me.MiExpedienteToolStripMenuItem.Text = "Mi expediente"
        '
        'PruebasToolStripMenuItem
        '
        Me.PruebasToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AgendarPruebaToolStripMenuItem, Me.MisPruebasToolStripMenuItem, Me.CrearNuevoTipoDePruebaToolStripMenuItem})
        Me.PruebasToolStripMenuItem.Name = "PruebasToolStripMenuItem"
        Me.PruebasToolStripMenuItem.Size = New System.Drawing.Size(99, 28)
        Me.PruebasToolStripMenuItem.Text = "Pruebas"
        '
        'AgendarPruebaToolStripMenuItem
        '
        Me.AgendarPruebaToolStripMenuItem.Name = "AgendarPruebaToolStripMenuItem"
        Me.AgendarPruebaToolStripMenuItem.Size = New System.Drawing.Size(349, 28)
        Me.AgendarPruebaToolStripMenuItem.Text = "Mantenimiento de Pruebas"
        '
        'MisPruebasToolStripMenuItem
        '
        Me.MisPruebasToolStripMenuItem.Name = "MisPruebasToolStripMenuItem"
        Me.MisPruebasToolStripMenuItem.Size = New System.Drawing.Size(349, 28)
        Me.MisPruebasToolStripMenuItem.Text = "Mis Pruebas"
        '
        'AnalitycsToolStripMenuItem
        '
        Me.AnalitycsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.VerReportesToolStripMenuItem, Me.AgregarTipoDeMétricaToolStripMenuItem})
        Me.AnalitycsToolStripMenuItem.Name = "AnalitycsToolStripMenuItem"
        Me.AnalitycsToolStripMenuItem.Size = New System.Drawing.Size(105, 28)
        Me.AnalitycsToolStripMenuItem.Text = "Analitycs"
        '
        'VerReportesToolStripMenuItem
        '
        Me.VerReportesToolStripMenuItem.Name = "VerReportesToolStripMenuItem"
        Me.VerReportesToolStripMenuItem.Size = New System.Drawing.Size(307, 28)
        Me.VerReportesToolStripMenuItem.Text = "Ver Reportes"
        '
        'AgregarTipoDeMétricaToolStripMenuItem
        '
        Me.AgregarTipoDeMétricaToolStripMenuItem.Name = "AgregarTipoDeMétricaToolStripMenuItem"
        Me.AgregarTipoDeMétricaToolStripMenuItem.Size = New System.Drawing.Size(307, 28)
        Me.AgregarTipoDeMétricaToolStripMenuItem.Text = "Agregar Tipo de Métrica"
        '
        'SalirToolStripMenuItem
        '
        Me.SalirToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SalirToolStripMenuItem1})
        Me.SalirToolStripMenuItem.Name = "SalirToolStripMenuItem"
        Me.SalirToolStripMenuItem.Size = New System.Drawing.Size(63, 28)
        Me.SalirToolStripMenuItem.Text = "Salir"
        '
        'SalirToolStripMenuItem1
        '
        Me.SalirToolStripMenuItem1.Name = "SalirToolStripMenuItem1"
        Me.SalirToolStripMenuItem1.Size = New System.Drawing.Size(121, 28)
        Me.SalirToolStripMenuItem1.Text = "Salir"
        '
        'LabelMenu
        '
        Me.LabelMenu.AutoSize = True
        Me.LabelMenu.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelMenu.Location = New System.Drawing.Point(119, 200)
        Me.LabelMenu.Name = "LabelMenu"
        Me.LabelMenu.Size = New System.Drawing.Size(41, 31)
        Me.LabelMenu.TabIndex = 6
        Me.LabelMenu.Text = "..."
        '
        'CrearNuevoTipoDePruebaToolStripMenuItem
        '
        Me.CrearNuevoTipoDePruebaToolStripMenuItem.Name = "CrearNuevoTipoDePruebaToolStripMenuItem"
        Me.CrearNuevoTipoDePruebaToolStripMenuItem.Size = New System.Drawing.Size(349, 28)
        Me.CrearNuevoTipoDePruebaToolStripMenuItem.Text = "Crear Nuevo Tipo de Prueba"
        '
        'CambiarTipoDeUsuarioToolStripMenuItem
        '
        Me.CambiarTipoDeUsuarioToolStripMenuItem.Name = "CambiarTipoDeUsuarioToolStripMenuItem"
        Me.CambiarTipoDeUsuarioToolStripMenuItem.Size = New System.Drawing.Size(336, 28)
        Me.CambiarTipoDeUsuarioToolStripMenuItem.Text = "Cambiar Tipo de Usuario"
        '
        'MenúPrincipal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(615, 377)
        Me.Controls.Add(Me.LabelMenu)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Name = "MenúPrincipal"
        Me.Text = "Menú Principal"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents AnalitycsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PruebasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExpedientesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExpedientesDeEmpleadosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExpedientesDeCandidatosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SalirToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SalirToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents MiExpedienteToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RegistroToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RegistroDeCandidatosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RegistroDeEmpleadosToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VerReportesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AgendarPruebaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LabelMenu As Label
    Friend WithEvents MisPruebasToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AgregarTipoDeMétricaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CrearNuevoTipoDePruebaToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CambiarTipoDeUsuarioToolStripMenuItem As ToolStripMenuItem
End Class
