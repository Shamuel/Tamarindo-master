﻿Imports System.Data.SqlClient

Public Class Metricas
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub busqueda_Click(sender As Object, e As EventArgs) Handles busqueda.Click
        If txtCedula.Text <> "" Then
            Try
                DataGridView1.Visible = True
                'Chart1.Visible = True
                'abrirConexion()

                Dim strSQL As String = "SELECT * FROM TBL_METRICA_503 WHERE FK_ID_500 = '" & txtCedula.Text & "' AND FK_TipoMetrica_504 = " & (cbxTiposMetricas.SelectedIndex + 1)


                Dim da As New SqlClient.SqlDataAdapter(strSQL, conexion)
                Dim ds As New DataSet



                If DataGridView1.Size <> Nothing Then
                    da.Fill(ds, "TBL_METRICA_503")
                    DataGridView1.DataSource = ds.Tables("TBL_METRICA_503")

                    DataGridView1.Columns(0).HeaderCell.Value = "Consecutivo"
                    DataGridView1.Columns(1).HeaderCell.Value = "ID Empleado"
                    DataGridView1.Columns(2).HeaderCell.Value = "Tipo Métrica"
                    DataGridView1.Columns(3).HeaderCell.Value = "Fecha Evaluación"
                    DataGridView1.Columns(4).HeaderCell.Value = "Resultado"

                    'Chart1.DataSource = ds.Tables("TBL_METRICA_503")
                    'Chart1.Series("Series1").XValueMember = "CP_FechaMetrica"
                    'Chart1.Series("Series1").YValueMembers = "CP_ResultadoMetrica"
                    'Chart1.DataBind()

                    ' conexion.Close()

                Else

                    MsgBox("No se ha encontrado Registro")
                    ' conexion.Close()
                End If


            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, "General Error")
            End Try
            '  conexion.Close()

            'Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Line
            'Chart1.Series(0).Points.Clear()
            'For Count As Integer = 0 To DataGridView1.Rows.Count - 1
            '    Chart1.Series(0).Points.AddXY(DataGridView1.Item(0, Count).Value, DataGridView1.Item(2, Count).Value)
            'Next
        Else
            MsgBox("Digite un número de empleado")
        End If

    End Sub

    Private Sub Metricas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGridView1.Visible = False

        Dim sqlquery As String = "SELECT CP_Descripion FROM TBL_TiposMetrica_504"
        Using strCombBx As SqlCommand = New SqlCommand(sqlquery, conexion)

            'conexion.Open()
            Dim reader As SqlDataReader = strCombBx.ExecuteReader
            Dim dtCB As New DataTable

            dtCB.Load(reader)
            cbxTiposMetricas.ValueMember = "Tipo de Métrica"
            cbxTiposMetricas.DisplayMember = "CP_Descripion"
            cbxTiposMetricas.DataSource = dtCB

            'conexion.Close()

        End Using



    End Sub

    Private Sub salir_Click(sender As Object, e As EventArgs) Handles salir.Click
        MenúPrincipal.Show()
        Me.Close()


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)
        Using writer As New System.IO.StreamWriter("Escritorio")
            For row As Integer = 0 To DataGridView1.RowCount - 2
                For col As Integer = 0 To DataGridView1.ColumnCount - 1
                    writer.WriteLine(DataGridView1.Rows(row).Cells(col).Value)
                Next
            Next
        End Using
    End Sub
End Class