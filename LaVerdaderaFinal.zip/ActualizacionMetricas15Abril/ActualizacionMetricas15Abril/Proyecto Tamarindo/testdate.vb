﻿Public Class testdate
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'Dim anterior As String = "SELECT MAX(PK_ConsecutivoPrueba) FROM TBL_RegistroDePruebas_501"
        'TextBox1.Text = anterior
        ' Dim thisDay As DateTime = DateTime.Today
        'TextBox1.Text = thisDay.ToString("yyyy-MM-dd hh:mm")
        'INSERT INTO TBL_RegistroDePruebas_501(PK_ConsecutivoPrueba, FK_Id_500, FK_IdTipoPrueba_100, CP_FechaAsignacion, CP_FechaRealizacion, CP_EstadoPrueba, CP_Calificacion) VALUES(1, '901100792', 1, '2018-04-07 12:00:00', '2018-04-14 12:00:00', 0,100)
        conexion.Open()

        TextBox1.Text = consecutivo().ToString

        conexion.Close()



    End Sub
End Class