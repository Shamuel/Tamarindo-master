﻿Public Class CrearTiposPrueba
    Private Sub cancelar_Click(sender As Object, e As EventArgs) Handles cancelar.Click
        Me.Close()

    End Sub

    Private Sub crearP_Click(sender As Object, e As EventArgs) Handles crearP.Click
        Dim crearPrueba As String = "INSERT INTO TBL_TiposDePrueba_501 VALUES('" & nombre.Text & "', '" & enunciado.Text & "')"

        If nombre.Text <> "" AndAlso enunciado.Text <> "" Then
            Try
                Insertar(crearPrueba)
                MsgBox("¡Prueba creada con éxito!")
                Me.Close()

            Catch ex As Exception
                MsgBox("Ha ocurrido un error, por favor intente de nuevo.")
            End Try
        Else
            MsgBox("Debe llenar todos los campos")
        End If
    End Sub
End Class