﻿Public Class RegistroCandidato

    Private Sub RegistroCandidato_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'conexion.Open()
        Modificar.Enabled = False
        Guardar.Enabled = False
        Eliminar.Enabled = False
        ModificarDatos.Visible = False
    End Sub

    Private Sub Nuevo_Click(sender As Object, e As EventArgs) Handles Nuevo.Click
        Modificar.Enabled = True
        Guardar.Enabled = True
        Eliminar.Enabled = True


    End Sub

    Private Sub Guardar_Click(sender As Object, e As EventArgs) Handles Guardar.Click
        Dim Agregar As String = "Insert into TBL_Persona_500 values" & "('" & Cedula.Text & "','" & TipoID.Text & "','" & Nombre.Text & "','" & PrimerApellido.Text & "','" & SegundoApellido.Text & "','" & Fecha.Value.Date.ToString(" yyyy-MM-dd hh:mm") & "','" & Telefono.Text & "','" & Correo.Text & "')"


        If Nombre.Text <> "" And Cedula.Text <> "" And PrimerApellido.Text <> "" And Correo.Text <> "" And SegundoApellido.Text <> "" Then

            If (TodoLaConexion.InsertarPersona(Agregar)) Then
                MsgBox("Datos Guardados Correctamente")
            Else
                MsgBox("Error al guardar los datos")
            End If

            Cedula.Clear()
            Nombre.Clear()
            Correo.Clear()
            Telefono.Clear()
            PrimerApellido.Clear()
            SegundoApellido.Clear()

        Else
            MsgBox("Escriba en Cada Campo")
        End If
    End Sub

    Private Sub Modificar_Click(sender As Object, e As EventArgs) Handles Modificar.Click
        TipoID.Enabled = False
        Fecha.Enabled = False


    End Sub

    Private Sub ModificarDatos_Click(sender As Object, e As EventArgs) Handles ModificarDatos.Click

        Dim modificar As String = "Update TBL_Persona_500 Set CP_Nombre = '" & Nombre.Text & "'," & "CP_Apellido1 = '" & PrimerApellido.Text & "'," & "CP_Apellido2 = '" & SegundoApellido.Text & "'," & "CP_Telefono1 = '" & Telefono.Text & "'," & "CP_Correo = '" & Correo.Text & "'" & "where PK_ID = '" & Cedula.Text & "';"

        If Nombre.Text <> "" And Cedula.Text <> "" And PrimerApellido.Text <> "" And Correo.Text <> "" And SegundoApellido.Text <> "" Then

            If (TodoLaConexion.InsertarPersona(modificar)) Then
                MsgBox("Datos Modificados Correctamente")
            Else
                MsgBox("Error al Modificar los datos")
            End If

            Cedula.Clear()
            Nombre.Clear()
            Correo.Clear()
            Telefono.Clear()
            PrimerApellido.Clear()
            SegundoApellido.Clear()

        Else
            MsgBox("Escriba en Cada Campo")
        End If
    End Sub
End Class
