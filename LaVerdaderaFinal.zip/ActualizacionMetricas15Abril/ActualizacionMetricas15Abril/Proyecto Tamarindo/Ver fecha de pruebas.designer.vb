﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Ver_fecha_de_pruebas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Ver_fecha_de_pruebas))
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Nuevo_tipo = New System.Windows.Forms.TextBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Salir = New System.Windows.Forms.Button()
        Me.Fechas = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.fghj = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Calificacion = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Cedula = New System.Windows.Forms.TextBox()
        Me.TipoPrueba = New System.Windows.Forms.ComboBox()
        Me.Anadir = New System.Windows.Forms.RadioButton()
        Me.Enviar = New System.Windows.Forms.Button()
        Me.Modificar = New System.Windows.Forms.RadioButton()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(808, 882)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(104, 33)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "Menu de pruebas"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(411, 837)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(104, 33)
        Me.Button4.TabIndex = 16
        Me.Button4.Text = "Actualizar"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(140, 762)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(101, 16)
        Me.Label7.TabIndex = 23
        Me.Label7.Text = "Tipo de prueba"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(140, 796)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(111, 16)
        Me.Label9.TabIndex = 25
        Me.Label9.Text = "Fecha de prueba"
        '
        'Nuevo_tipo
        '
        Me.Nuevo_tipo.Location = New System.Drawing.Point(257, 761)
        Me.Nuevo_tipo.Name = "Nuevo_tipo"
        Me.Nuevo_tipo.Size = New System.Drawing.Size(449, 20)
        Me.Nuevo_tipo.TabIndex = 27
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(257, 796)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(449, 20)
        Me.DateTimePicker1.TabIndex = 28
        '
        'Salir
        '
        Me.Salir.Font = New System.Drawing.Font("Calibri", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Salir.Location = New System.Drawing.Point(734, 333)
        Me.Salir.Name = "Salir"
        Me.Salir.Size = New System.Drawing.Size(164, 65)
        Me.Salir.TabIndex = 32
        Me.Salir.Text = "Salir"
        Me.Salir.UseVisualStyleBackColor = True
        '
        'Fechas
        '
        Me.Fechas.Location = New System.Drawing.Point(187, 236)
        Me.Fechas.Name = "Fechas"
        Me.Fechas.Size = New System.Drawing.Size(201, 20)
        Me.Fechas.TabIndex = 33
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Calibri", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(25, 236)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 26)
        Me.Label1.TabIndex = 34
        Me.Label1.Text = "Fecha:"
        '
        'fghj
        '
        Me.fghj.AutoSize = True
        Me.fghj.Font = New System.Drawing.Font("Calibri", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fghj.Location = New System.Drawing.Point(25, 187)
        Me.fghj.Name = "fghj"
        Me.fghj.Size = New System.Drawing.Size(146, 26)
        Me.fghj.TabIndex = 35
        Me.fghj.Text = "Tipo de Prueba:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Calibri", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(25, 141)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(115, 26)
        Me.Label3.TabIndex = 37
        Me.Label3.Text = "Calificacion:"
        '
        'Calificacion
        '
        Me.Calificacion.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Calificacion.Location = New System.Drawing.Point(187, 141)
        Me.Calificacion.Name = "Calificacion"
        Me.Calificacion.Size = New System.Drawing.Size(201, 31)
        Me.Calificacion.TabIndex = 38
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Calibri", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(25, 98)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(76, 26)
        Me.Label4.TabIndex = 39
        Me.Label4.Text = "Cedula:"
        '
        'Cedula
        '
        Me.Cedula.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cedula.Location = New System.Drawing.Point(187, 93)
        Me.Cedula.Name = "Cedula"
        Me.Cedula.Size = New System.Drawing.Size(201, 31)
        Me.Cedula.TabIndex = 40
        '
        'TipoPrueba
        '
        Me.TipoPrueba.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TipoPrueba.FormattingEnabled = True
        Me.TipoPrueba.Items.AddRange(New Object() {"1", "2", "3", "4"})
        Me.TipoPrueba.Location = New System.Drawing.Point(187, 187)
        Me.TipoPrueba.Name = "TipoPrueba"
        Me.TipoPrueba.Size = New System.Drawing.Size(201, 31)
        Me.TipoPrueba.TabIndex = 42
        '
        'Anadir
        '
        Me.Anadir.AutoSize = True
        Me.Anadir.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Anadir.Location = New System.Drawing.Point(30, 31)
        Me.Anadir.Name = "Anadir"
        Me.Anadir.Size = New System.Drawing.Size(79, 27)
        Me.Anadir.TabIndex = 43
        Me.Anadir.TabStop = True
        Me.Anadir.Text = "Añadir"
        Me.Anadir.UseVisualStyleBackColor = True
        '
        'Enviar
        '
        Me.Enviar.Font = New System.Drawing.Font("Calibri", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Enviar.Location = New System.Drawing.Point(30, 298)
        Me.Enviar.Name = "Enviar"
        Me.Enviar.Size = New System.Drawing.Size(164, 65)
        Me.Enviar.TabIndex = 44
        Me.Enviar.Text = "Enviar"
        Me.Enviar.UseVisualStyleBackColor = True
        '
        'Modificar
        '
        Me.Modificar.AutoSize = True
        Me.Modificar.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Modificar.Location = New System.Drawing.Point(115, 31)
        Me.Modificar.Name = "Modificar"
        Me.Modificar.Size = New System.Drawing.Size(102, 27)
        Me.Modificar.TabIndex = 45
        Me.Modificar.TabStop = True
        Me.Modificar.Text = "Modificar"
        Me.Modificar.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Calibri", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(638, 31)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(242, 40)
        Me.Button2.TabIndex = 46
        Me.Button2.Text = "Ver Pruebas Existentes"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(455, 93)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(425, 163)
        Me.DataGridView1.TabIndex = 47
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Calibri", 2.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(734, 259)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(26, 4)
        Me.Label2.TabIndex = 48
        Me.Label2.Text = "Tipo de Prueba:"
        '
        'Ver_fecha_de_pruebas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(910, 410)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Modificar)
        Me.Controls.Add(Me.Enviar)
        Me.Controls.Add(Me.Anadir)
        Me.Controls.Add(Me.TipoPrueba)
        Me.Controls.Add(Me.Cedula)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Calificacion)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.fghj)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Fechas)
        Me.Controls.Add(Me.Salir)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.Nuevo_tipo)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Ver_fecha_de_pruebas"
        Me.Text = "Pruebas"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Label7 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Nuevo_tipo As TextBox
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents Salir As Button
    Friend WithEvents Fechas As DateTimePicker
    Friend WithEvents Label1 As Label
    Friend WithEvents fghj As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Calificacion As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Cedula As TextBox
    Friend WithEvents TipoPrueba As ComboBox
    Friend WithEvents Anadir As RadioButton
    Friend WithEvents Enviar As Button
    Friend WithEvents Modificar As RadioButton
    Friend WithEvents Button2 As Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Label2 As Label
    Friend WithEvents ToolTip1 As ToolTip
End Class
