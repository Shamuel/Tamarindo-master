﻿Module TodoLaConexion
    '1- Definir nombre del servidor y la base de datos para conexion
    Public servidor_datos As String = "Data Source=LAPTOP-MIG91646;Initial Catalog=Tamarindo;Integrated Security=SSPI;"
    '2- Definir una conexion para la base de datos
    Public conexion As New SqlClient.SqlConnection(servidor_datos)
    Public instruccionSQL As SqlClient.SqlCommand
    Public Respuesta As SqlClient.SqlDataReader
    Public userID As String
    'sub para abrir conexion
    Sub abrirConexion()
        Try
            conexion.Open()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try


    End Sub
    'funcion para obtener usuarios de la BD
    Function UsuarioRegistrado(ByVal NombredeUsuario As String) As Boolean
        Dim ResultadoConexion As Boolean = False
        Try
            instruccionSQL = New SqlClient.SqlCommand("Select * from TBL_Usuario_102 where PK_IdUsuario='" & NombredeUsuario & "'", conexion)
            Respuesta = instruccionSQL.ExecuteReader

            If Respuesta.Read Then
                ResultadoConexion = True
            End If
            Respuesta.Close()

        Catch ex As Exception

        End Try
        Return ResultadoConexion
    End Function

    'funcion para obtener usuarios de la BD
    Function contrasena(ByVal NombredeUsuario As String) As String
        Dim ResultadoConexion As String = ""
        Try
            instruccionSQL = New SqlClient.SqlCommand("Select CP_Contrasena from TBL_Usuario_102 where PK_IdUsuario='" & NombredeUsuario & "'", conexion)
            Respuesta = instruccionSQL.ExecuteReader

            If Respuesta.Read Then
                ResultadoConexion = Respuesta.Item("CP_Contrasena")
            End If
            Respuesta.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return ResultadoConexion
    End Function

    Function Insertar(ByVal sql)
        'conexion.Open()
        instruccionSQL = New SqlClient.SqlCommand(sql, conexion)
        Dim i As Integer = instruccionSQL.ExecuteNonQuery
        If (i > 0) Then
            Return True
        Else
            Return False
        End If

    End Function

    Function InsertarPersona(ByVal sql)
        'conexion.Open()
        instruccionSQL = New SqlClient.SqlCommand(sql, conexion)
        Dim i As Integer = instruccionSQL.ExecuteNonQuery
        If (i > 0) Then
            Return True
        Else
            Return False
        End If

    End Function

    Function ConsultarID(ByVal CorreoUsuario As String) As String
        Dim ResultadoConexion As String = ""
        Try
            instruccionSQL = New SqlClient.SqlCommand("SELECT PK_ID FROM TBL_Persona_500 WHERE CP_Correo = '" & CorreoUsuario & "'", conexion)
            Respuesta = instruccionSQL.ExecuteReader

            If Respuesta.Read Then
                ResultadoConexion = Respuesta.Item("PK_ID")

            End If
            Respuesta.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return ResultadoConexion
    End Function

    Function IDRegistrado(ByVal NombreUsuario As String) As String
        Dim ResultadoConexion As String = ""
        Try
            instruccionSQL = New SqlClient.SqlCommand("SELECT FK_Id_500 FROM TBL_Usuario_102 WHERE PK_IdUsuario = '" & NombreUsuario & "'", conexion)
            Respuesta = instruccionSQL.ExecuteReader

            If Respuesta.Read Then
                ResultadoConexion = Respuesta.Item("FK_Id_500")

            End If
            Respuesta.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return ResultadoConexion
    End Function

    Function validarContrasena(ByVal contraValida As String,
                               Optional ByVal caracMin As Integer = 8,
                               Optional ByVal caracMax As Integer = 50,
                               Optional ByVal minMayus As Integer = 1,
                               Optional ByVal minMinus As Integer = 1,
                               Optional ByVal minNumeros As Integer = 1) As Boolean
        Dim upper As New System.Text.RegularExpressions.Regex("[A-Z]")
        Dim lower As New System.Text.RegularExpressions.Regex("[a-z]")
        Dim number As New System.Text.RegularExpressions.Regex("[0-9]")

        If Len(contraValida) < caracMin Then Return False
        If Len(contraValida) > caracMax Then Return False
        If upper.Matches(contraValida).Count < minMayus Then Return False
        If lower.Matches(contraValida).Count < minMinus Then Return False
        If number.Matches(contraValida).Count < minNumeros Then Return False

        Return True
    End Function
    Function BloquearUsuarios(ByVal NombredeUsuario As String) As Integer
        Dim ResultadoConexion As Integer
        Try
            instruccionSQL = New SqlClient.SqlCommand("Select CP_Contador_CambioContrasena from TBL_Usuario_102 where PK_IdUsuario='" & NombredeUsuario & "'", conexion)
            Respuesta = instruccionSQL.ExecuteReader

            If Respuesta.Read Then
                ResultadoConexion = Respuesta.Item("CP_Contador_CambioContrasena")
            End If
            Respuesta.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return ResultadoConexion
    End Function

    Function TipoUsuario(ByVal ID As String) As Integer
        Dim ResultadoConexion As Integer
        Try
            'conexion.Open()

            instruccionSQL = New SqlClient.SqlCommand("Select FK_TipoUsuario_103 from TBL_Usuario_102 where PK_IdUsuario='" & ID & "'", conexion)
            Respuesta = instruccionSQL.ExecuteReader

            If Respuesta.Read Then
                ResultadoConexion = Respuesta.Item("FK_TipoUsuario_103")
            End If
            Respuesta.Close()
            'conexion.Close()

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return ResultadoConexion
    End Function

    Public ds As New DataSet()
    Public da As SqlClient.SqlDataAdapter


    Public Function Consultar2(tabla As String) As DataTable
        Dim sql As String = "select * from " & tabla
        da = New SqlClient.SqlDataAdapter(sql, conexion)
        Dim dts As New DataSet()
        da.Fill(dts, tabla)
        Dim dt As New DataTable()
        dt = dts.Tables(tabla)
        Return dt

    End Function

    Public Function Insertar2(sql As String) As Boolean
        conexion.Open()
        instruccionSQL = New SqlClient.SqlCommand(sql, conexion)
        Dim i As Integer = instruccionSQL.ExecuteNonQuery()
        conexion.Close()
        If i > 0 Then
            Return True
        Else
            Return False

        End If
    End Function

    'Public Function FechaContrasena(fechaCambio As String) As Boolean
    'Dim thisDay As DateTime = DateTime.Today
    '   thisDay.ToString("yyyy-MM-dd hh:mm")


    'End Function


    Function consecutivo() As String
        Dim max As Integer
        Try
            instruccionSQL = New SqlClient.SqlCommand("SELECT MAX(PK_ConsecutivoPrueba) FROM TBL_RegistroDePruebas_501", conexion)
            Respuesta = instruccionSQL.ExecuteReader

            'If Respuesta.Read Then
            'max = Respuesta.Item("PK_ConsecutivoPrueba")
            'End If
            Respuesta.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return max
    End Function

    Function vencimiento(ByVal userId As String) As String
        Dim ResultadoConexion As String
        Dim dias As String = ""
        Try
            instruccionSQL = New SqlClient.SqlCommand("SELECT CP_FechaCambioContrasena from TBL_Usuario_102 where PK_IdUsuario ='" & userId & "'", conexion)

            Respuesta = instruccionSQL.ExecuteReader
            If Respuesta.Read Then
                ResultadoConexion = Respuesta.Item("CP_FechaCambioContrasena")
            End If

            '("CP_Fecha iclusion") 

            dias = DateDiff(DateInterval.Day, Convert.ToDateTime(ResultadoConexion), Convert.ToDateTime(Date.Today)).ToString

            Respuesta.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)

        End Try
        Return dias
    End Function


End Module
