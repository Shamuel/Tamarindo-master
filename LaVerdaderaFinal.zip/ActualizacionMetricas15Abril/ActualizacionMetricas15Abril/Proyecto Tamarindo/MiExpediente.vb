﻿Imports System.Data.SqlClient

Public Class miExpediente
    Private Sub miExpediente_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        Dim instruccionSQL = "SELECT CP_Nombre, CP_Apellido1, CP_Apellido2, CP_FechaIngreso, CP_Telefono1, CP_Correo FROM TBL_Persona_500 WHERE PK_ID = '" & IDRegistrado(userID) & "'"
        Dim comando As New SqlCommand(instruccionSQL, conexion)
        Dim reader As SqlDataReader = comando.ExecuteReader()
        If reader.HasRows Then
            reader.Read()
            TextBoxNombre.Text = reader.Item("CP_Nombre")
            TextBoxApellido1.Text = reader.Item("CP_Apellido1")
            TextBoxApellido2.Text = reader.Item("CP_Apellido2")
            DateTimePicker1.Text = reader.Item("CP_FechaIngreso")
            TextBoxTelefono.Text = reader.Item("CP_Telefono1")
            TextBoxCorreo.Text = reader.Item("CP_Correo")
            reader.Close()
        Else
            MsgBox("No se encuentra registro")
        End If


        Me.TextBoxNombre.Enabled = False
        Me.DateTimePicker1.Enabled = False
        Me.TextBoxID.Enabled = False
        Me.TextBoxTelefono.Enabled = True
        Me.TextBoxCorreo.Enabled = True

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class