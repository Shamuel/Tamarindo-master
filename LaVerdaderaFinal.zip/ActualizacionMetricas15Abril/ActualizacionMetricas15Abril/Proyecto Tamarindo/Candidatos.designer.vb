﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RegistroCandidato
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(RegistroCandidato))
        Me.Correo = New System.Windows.Forms.TextBox()
        Me.Buscar = New System.Windows.Forms.Button()
        Me.Nombre = New System.Windows.Forms.TextBox()
        Me.Cedula = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Salir = New System.Windows.Forms.Button()
        Me.Eliminar = New System.Windows.Forms.Button()
        Me.Guardar = New System.Windows.Forms.Button()
        Me.Modificar = New System.Windows.Forms.Button()
        Me.Nuevo = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TipoID = New System.Windows.Forms.ComboBox()
        Me.SegundoApellido = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.PrimerApellido = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Telefono = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Fecha = New System.Windows.Forms.DateTimePicker()
        Me.ModificarDatos = New System.Windows.Forms.Button()
        Me.EliminarSeguro = New System.Windows.Forms.Button()
        Me.Cancelar = New System.Windows.Forms.Button()
        Me.Cancelar1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Correo
        '
        Me.Correo.Location = New System.Drawing.Point(205, 347)
        Me.Correo.Multiline = True
        Me.Correo.Name = "Correo"
        Me.Correo.Size = New System.Drawing.Size(211, 19)
        Me.Correo.TabIndex = 11
        '
        'Buscar
        '
        Me.Buscar.BackgroundImage = CType(resources.GetObject("Buscar.BackgroundImage"), System.Drawing.Image)
        Me.Buscar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Buscar.Location = New System.Drawing.Point(448, 30)
        Me.Buscar.Name = "Buscar"
        Me.Buscar.Size = New System.Drawing.Size(41, 24)
        Me.Buscar.TabIndex = 29
        Me.Buscar.Text = "."
        Me.Buscar.UseVisualStyleBackColor = True
        '
        'Nombre
        '
        Me.Nombre.Location = New System.Drawing.Point(205, 116)
        Me.Nombre.Multiline = True
        Me.Nombre.Name = "Nombre"
        Me.Nombre.Size = New System.Drawing.Size(211, 20)
        Me.Nombre.TabIndex = 25
        '
        'Cedula
        '
        Me.Cedula.Location = New System.Drawing.Point(205, 26)
        Me.Cedula.Multiline = True
        Me.Cedula.Name = "Cedula"
        Me.Cedula.Size = New System.Drawing.Size(211, 21)
        Me.Cedula.TabIndex = 24
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(42, 348)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(157, 18)
        Me.Label4.TabIndex = 22
        Me.Label4.Text = "Correo Electrónico:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(44, 116)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(73, 18)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = "Nombre:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(52, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(65, 18)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "Cédula:"
        '
        'Salir
        '
        Me.Salir.BackColor = System.Drawing.Color.LimeGreen
        Me.Salir.Font = New System.Drawing.Font("Calibri", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Salir.ForeColor = System.Drawing.Color.White
        Me.Salir.Location = New System.Drawing.Point(706, 445)
        Me.Salir.Name = "Salir"
        Me.Salir.Size = New System.Drawing.Size(118, 51)
        Me.Salir.TabIndex = 34
        Me.Salir.Text = "Salir"
        Me.Salir.UseVisualStyleBackColor = False
        '
        'Eliminar
        '
        Me.Eliminar.BackColor = System.Drawing.Color.White
        Me.Eliminar.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Eliminar.ForeColor = System.Drawing.Color.LimeGreen
        Me.Eliminar.Location = New System.Drawing.Point(379, 445)
        Me.Eliminar.Name = "Eliminar"
        Me.Eliminar.Size = New System.Drawing.Size(93, 33)
        Me.Eliminar.TabIndex = 33
        Me.Eliminar.Text = "Eliminar"
        Me.Eliminar.UseVisualStyleBackColor = False
        '
        'Guardar
        '
        Me.Guardar.BackColor = System.Drawing.Color.White
        Me.Guardar.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guardar.ForeColor = System.Drawing.Color.LimeGreen
        Me.Guardar.Location = New System.Drawing.Point(251, 445)
        Me.Guardar.Name = "Guardar"
        Me.Guardar.Size = New System.Drawing.Size(93, 33)
        Me.Guardar.TabIndex = 32
        Me.Guardar.Text = "Guardar"
        Me.Guardar.UseVisualStyleBackColor = False
        '
        'Modificar
        '
        Me.Modificar.BackColor = System.Drawing.Color.White
        Me.Modificar.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Modificar.ForeColor = System.Drawing.Color.LimeGreen
        Me.Modificar.Location = New System.Drawing.Point(135, 445)
        Me.Modificar.Name = "Modificar"
        Me.Modificar.Size = New System.Drawing.Size(93, 33)
        Me.Modificar.TabIndex = 31
        Me.Modificar.Text = "Modificar"
        Me.Modificar.UseVisualStyleBackColor = False
        '
        'Nuevo
        '
        Me.Nuevo.BackColor = System.Drawing.Color.White
        Me.Nuevo.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Nuevo.ForeColor = System.Drawing.Color.LimeGreen
        Me.Nuevo.Location = New System.Drawing.Point(12, 445)
        Me.Nuevo.Name = "Nuevo"
        Me.Nuevo.Size = New System.Drawing.Size(93, 33)
        Me.Nuevo.TabIndex = 30
        Me.Nuevo.Text = "Nuevo"
        Me.Nuevo.UseVisualStyleBackColor = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(42, 72)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(85, 18)
        Me.Label6.TabIndex = 35
        Me.Label6.Text = "Tipo de ID"
        '
        'TipoID
        '
        Me.TipoID.FormattingEnabled = True
        Me.TipoID.Items.AddRange(New Object() {"1", "2", "3"})
        Me.TipoID.Location = New System.Drawing.Point(205, 69)
        Me.TipoID.Name = "TipoID"
        Me.TipoID.Size = New System.Drawing.Size(211, 21)
        Me.TipoID.TabIndex = 36
        '
        'SegundoApellido
        '
        Me.SegundoApellido.Location = New System.Drawing.Point(205, 214)
        Me.SegundoApellido.Multiline = True
        Me.SegundoApellido.Name = "SegundoApellido"
        Me.SegundoApellido.Size = New System.Drawing.Size(211, 20)
        Me.SegundoApellido.TabIndex = 38
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(42, 213)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(143, 18)
        Me.Label5.TabIndex = 37
        Me.Label5.Text = "Segundo Apellido:"
        '
        'PrimerApellido
        '
        Me.PrimerApellido.Location = New System.Drawing.Point(205, 165)
        Me.PrimerApellido.Multiline = True
        Me.PrimerApellido.Name = "PrimerApellido"
        Me.PrimerApellido.Size = New System.Drawing.Size(211, 20)
        Me.PrimerApellido.TabIndex = 40
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(44, 167)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(127, 18)
        Me.Label8.TabIndex = 39
        Me.Label8.Text = "Primer Apellido:"
        '
        'Telefono
        '
        Me.Telefono.Location = New System.Drawing.Point(205, 304)
        Me.Telefono.Multiline = True
        Me.Telefono.Name = "Telefono"
        Me.Telefono.Size = New System.Drawing.Size(211, 21)
        Me.Telefono.TabIndex = 42
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(44, 307)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(79, 18)
        Me.Label9.TabIndex = 41
        Me.Label9.Text = "Telefono:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(44, 260)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(120, 18)
        Me.Label3.TabIndex = 43
        Me.Label3.Text = "Fecha Ingreso:"
        '
        'Fecha
        '
        Me.Fecha.Location = New System.Drawing.Point(205, 258)
        Me.Fecha.Name = "Fecha"
        Me.Fecha.Size = New System.Drawing.Size(211, 20)
        Me.Fecha.TabIndex = 44
        '
        'ModificarDatos
        '
        Me.ModificarDatos.BackColor = System.Drawing.Color.White
        Me.ModificarDatos.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModificarDatos.ForeColor = System.Drawing.Color.LimeGreen
        Me.ModificarDatos.Location = New System.Drawing.Point(464, 327)
        Me.ModificarDatos.Name = "ModificarDatos"
        Me.ModificarDatos.Size = New System.Drawing.Size(137, 59)
        Me.ModificarDatos.TabIndex = 45
        Me.ModificarDatos.Text = "Modificar Datos"
        Me.ModificarDatos.UseVisualStyleBackColor = False
        '
        'EliminarSeguro
        '
        Me.EliminarSeguro.BackColor = System.Drawing.Color.White
        Me.EliminarSeguro.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EliminarSeguro.ForeColor = System.Drawing.Color.LimeGreen
        Me.EliminarSeguro.Location = New System.Drawing.Point(167, 94)
        Me.EliminarSeguro.Name = "EliminarSeguro"
        Me.EliminarSeguro.Size = New System.Drawing.Size(137, 59)
        Me.EliminarSeguro.TabIndex = 46
        Me.EliminarSeguro.Text = "Eliminar Candidato"
        Me.EliminarSeguro.UseVisualStyleBackColor = False
        '
        'Cancelar
        '
        Me.Cancelar.BackColor = System.Drawing.Color.White
        Me.Cancelar.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cancelar.ForeColor = System.Drawing.Color.LimeGreen
        Me.Cancelar.Location = New System.Drawing.Point(335, 94)
        Me.Cancelar.Name = "Cancelar"
        Me.Cancelar.Size = New System.Drawing.Size(137, 59)
        Me.Cancelar.TabIndex = 47
        Me.Cancelar.Text = "Cancelar"
        Me.Cancelar.UseVisualStyleBackColor = False
        '
        'Cancelar1
        '
        Me.Cancelar1.BackColor = System.Drawing.Color.White
        Me.Cancelar1.Font = New System.Drawing.Font("Calibri", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cancelar1.ForeColor = System.Drawing.Color.LimeGreen
        Me.Cancelar1.Location = New System.Drawing.Point(643, 327)
        Me.Cancelar1.Name = "Cancelar1"
        Me.Cancelar1.Size = New System.Drawing.Size(137, 59)
        Me.Cancelar1.TabIndex = 48
        Me.Cancelar1.Text = "Cancelar"
        Me.Cancelar1.UseVisualStyleBackColor = False
        '
        'RegistroCandidato
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(836, 520)
        Me.Controls.Add(Me.Cancelar1)
        Me.Controls.Add(Me.Cancelar)
        Me.Controls.Add(Me.EliminarSeguro)
        Me.Controls.Add(Me.ModificarDatos)
        Me.Controls.Add(Me.Fecha)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Telefono)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.PrimerApellido)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.SegundoApellido)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.TipoID)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Salir)
        Me.Controls.Add(Me.Eliminar)
        Me.Controls.Add(Me.Guardar)
        Me.Controls.Add(Me.Modificar)
        Me.Controls.Add(Me.Nuevo)
        Me.Controls.Add(Me.Buscar)
        Me.Controls.Add(Me.Nombre)
        Me.Controls.Add(Me.Cedula)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Correo)
        Me.Name = "RegistroCandidato"
        Me.Text = "Registro Candidatos"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Correo As TextBox
    Friend WithEvents Buscar As Button
    Friend WithEvents Nombre As TextBox
    Friend WithEvents Cedula As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Salir As Button
    Friend WithEvents Eliminar As Button
    Friend WithEvents Guardar As Button
    Friend WithEvents Modificar As Button
    Friend WithEvents Nuevo As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents TipoID As ComboBox
    Friend WithEvents SegundoApellido As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents PrimerApellido As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Telefono As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Fecha As DateTimePicker
    Friend WithEvents ModificarDatos As Button
    Friend WithEvents EliminarSeguro As Button
    Friend WithEvents Cancelar As Button
    Friend WithEvents Cancelar1 As Button
End Class
