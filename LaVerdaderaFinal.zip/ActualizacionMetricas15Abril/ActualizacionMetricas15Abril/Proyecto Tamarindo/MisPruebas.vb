﻿Public Class MisPruebas
    Private Sub MisPruebas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim misPruebas As String = "SELECT * FROM TBL_RegistroDePruebas_501 WHERE FK_Id_500 = '" & IDRegistrado(userID) & "'"

        Dim adaptador As SqlClient.SqlDataAdapter
        Dim set_de_datos As New DataSet()

        DataGridView1.DataSource = ""
        adaptador = New SqlClient.SqlDataAdapter(misPruebas, conexion)
        adaptador.Fill(set_de_datos, "TBL_RegistroDePruebas_501")
        DataGridView1.DataSource = set_de_datos.Tables("TBL_RegistroDePruebas_501")
        DataGridView1.Columns(0).HeaderCell.Value = "Consecutivo"
        DataGridView1.Columns(1).HeaderCell.Value = "Identifiación"
        DataGridView1.Columns(2).HeaderCell.Value = "Tipo de Prueba"
        DataGridView1.Columns(3).HeaderCell.Value = "Fecha de Asignación"
        DataGridView1.Columns(4).HeaderCell.Value = "Fecha de Realización"
        DataGridView1.Columns(5).HeaderCell.Value = "¿Prueba Realizada?"
        DataGridView1.Columns(6).HeaderCell.Value = "Calificación"

        '8- Enviar mensaje si encontr� o no encontro datos
        'Me.Label2.Text = DataGridView1.Rows.Count - 1
        If DataGridView1.Rows.Count > 1 Then
            'MessageBox.Show("LO ENCONTRO!", "MENSAJE DEL SISTEMA",
            'MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
        Else
            MessageBox.Show("NO HAY DATOS PARA MOSTRAR!", "MENSAJE DEL SISTEMA",
   MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
        End If

    End Sub

    Private Sub salir_Click(sender As Object, e As EventArgs) Handles salir.Click
        Me.Close()


    End Sub
End Class