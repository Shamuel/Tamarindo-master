﻿Public Class CrearMetrica
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub cancelar_Click(sender As Object, e As EventArgs) Handles cancelar.Click
        Me.Close()

    End Sub

    Private Sub crearM_Click(sender As Object, e As EventArgs) Handles crearM.Click
        Dim crearMetrica As String = "INSERT INTO TBL_TiposMetrica_504 VALUES('" & Descripcion.Text & "', '" & formula.Text & "')"

        If Descripcion.Text <> "" AndAlso formula.Text <> "" Then
            Try
                Insertar(crearMetrica)
                MsgBox("¡Métrica creada con éxito!")
                Me.Close()

            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, "Error")
            End Try

        Else
            MsgBox("Debe llenar todos los campos")
        End If

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub
End Class