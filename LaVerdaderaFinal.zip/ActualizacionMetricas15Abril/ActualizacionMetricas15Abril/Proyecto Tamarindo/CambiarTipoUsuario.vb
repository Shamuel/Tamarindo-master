﻿Imports System.Data.SqlClient

Public Class CambiarTipoUsuario
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim modificar As String = "Update TBL_Usuario_102 Set FK_TipoUsuario_103 = '" & (TipoUsuario.SelectedIndex + 1) & "' WHERE PK_IdUsuario = '" & NombreUsuario.Text & "'"
        Insertar(modificar)
        MsgBox("Datos Guardados Correctamente")
        Try
            '4- Crear adaptador para llenar el dataset  
            Dim adaptador As SqlClient.SqlDataAdapter
            '5- Definir el dataset
            Dim set_de_datos As New DataSet()
            '6- Definir la variable para la instruccion SQL
            Dim instruccionSQL As String
            instruccionSQL = "SELECT PK_IdUsuario, FK_Id_500, FK_TipoUsuario_103 FROM TBL_Usuario_102 WHERE PK_IdUsuario = '" & NombreUsuario.Text & "'"

            '7- Cargar el datagridview
            DataGridView1.DataSource = ""
            adaptador = New SqlClient.SqlDataAdapter(instruccionSQL, conexion)
            adaptador.Fill(set_de_datos, "TBL_Usuario_102")
            DataGridView1.DataSource = set_de_datos.Tables("TBL_Usuario_102")

            DataGridView1.Columns(0).HeaderCell.Value = "Nombre de Usuario"
            DataGridView1.Columns(1).HeaderCell.Value = "ID Empleado"
            DataGridView1.Columns(2).HeaderCell.Value = "Tipo de Usuario"

            '8- Enviar mensaje si encontr� o no encontro datos
            Me.Label2.Text = DataGridView1.Rows.Count - 1
            If DataGridView1.Rows.Count > 1 Then
                'MessageBox.Show("LO ENCONTRO!", "MENSAJE DEL SISTEMA",
                'MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
            Else
                MessageBox.Show("NO HAY DATOS PARA MOSTRAR!", "MENSAJE DEL SISTEMA",
       MessageBoxButtons.OK, MessageBoxIcon.Asterisk)

            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
        'conexion.Close()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub CambiarTipoUsuario_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim sqlquery As String = "SELECT CP_Descripcion FROM TBL_TipoUsuario_103"
        Using strCombBx As SqlCommand = New SqlCommand(sqlquery, conexion)

            'conexion.Open()
            Dim reader As SqlDataReader = strCombBx.ExecuteReader
            Dim dtCB As New DataTable

            dtCB.Load(reader)
            TipoUsuario.ValueMember = "Tipo de Usuario"
            TipoUsuario.DisplayMember = "CP_Descripcion"
            TipoUsuario.DataSource = dtCB

            'conexion.Close()

        End Using
    End Sub

    Private Sub mostrar_Click(sender As Object, e As EventArgs) Handles mostrar.Click

        Try
                DataGridView1.Visible = True
            'Chart1.Visible = True
            'abrirConexion()

            Dim strSQL As String = "SELECT PK_IdUsuario, FK_Id_500, FK_TipoUsuario_103, CP_FechaCambioContrasena, CP_EstadoBloqueo, CP_Fecha_Inclusion FROM TBL_Usuario_102"


            Dim da As New SqlClient.SqlDataAdapter(strSQL, conexion)
                Dim ds As New DataSet



                If DataGridView1.Size <> Nothing Then
                    da.Fill(ds, "TBL_Usuario_102")
                    DataGridView1.DataSource = ds.Tables("TBL_Usuario_102")

                    DataGridView1.Columns(0).HeaderCell.Value = "Nombre de Usuario"
                    DataGridView1.Columns(1).HeaderCell.Value = "ID Usuario"
                    DataGridView1.Columns(2).HeaderCell.Value = "Tipo de Usuario"
                DataGridView1.Columns(3).HeaderCell.Value = "Fecha Cambio de Contraseña"
                DataGridView1.Columns(4).HeaderCell.Value = "¿Bloqueado?"
                DataGridView1.Columns(5).HeaderCell.Value = "Fecha de Inclusión"

                'Chart1.DataSource = ds.Tables("TBL_METRICA_503")
                'Chart1.Series("Series1").XValueMember = "CP_FechaMetrica"
                'Chart1.Series("Series1").YValueMembers = "CP_ResultadoMetrica"
                'Chart1.DataBind()

                ' conexion.Close()

            Else

                    MsgBox("No se ha encontrado Registro")
                    ' conexion.Close()
                End If


            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, "General Error")
            End Try

    End Sub
End Class