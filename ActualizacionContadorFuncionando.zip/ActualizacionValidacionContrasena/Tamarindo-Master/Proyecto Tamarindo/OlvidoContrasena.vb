﻿Public Class OlvidoContrasena
    Private Sub OlvidoContrasena_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label2.Visible = False
        Label3.Visible = False
        Label4.Visible = False
        NuevaContrasena.Visible = False
        RepitaContrasena.Visible = False
        CodigoConfirmacion.Visible = False
        CambiarContrasena.Visible = False
        IngreseCorreo.Visible = True
        EnviarCodigo.Visible = True
    End Sub

    Public CodigoContrasena As String
    Public CorreoUsuario As String
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles EnviarCodigo.Click
        CorreoUsuario = IngreseCorreo.Text
        If ConsultarID(CorreoUsuario) <> "" Then


            Try

                Dim SmtpServer As New Net.Mail.SmtpClient()
                Dim mail As New Net.Mail.MailMessage()
                SmtpServer.UseDefaultCredentials = False
                SmtpServer.Credentials = New Net.NetworkCredential("proyecto1tamarindo@gmail.com", "sistemaHRtamarindo")
                SmtpServer.Port = 587
                SmtpServer.Host = "smtp.gmail.com"
                SmtpServer.EnableSsl = True
                SmtpServer.DeliveryMethod = Net.Mail.SmtpDeliveryMethod.Network
                mail = New Net.Mail.MailMessage()
                mail.From = New Net.Mail.MailAddress("proyecto1tamarindo@gmail.com")
                mail.To.Add(IngreseCorreo.Text)
                mail.Subject = "MailSubject"
                mail.Body = ""
                If mail.Body = "" Then
                    Dim rng As New Random
                    Dim number As Integer = rng.Next(1000, 9999)
                    CodigoContrasena = number.ToString("0000")
                    mail.Body = CodigoContrasena

                End If
                SmtpServer.Send(mail)
                IngreseCorreo.Clear()
                MsgBox("¡Código enviado con éxito!")
                Label2.Visible = True
                Label3.Visible = True
                Label4.Visible = True
                NuevaContrasena.Visible = True
                RepitaContrasena.Visible = True
                CodigoConfirmacion.Visible = True
                CambiarContrasena.Visible = True
                IngreseCorreo.Visible = False
                EnviarCodigo.Visible = False
            Catch ex As Exception
                MessageBox.Show("Error", "Error al enviar", MessageBoxButtons.OK, MessageBoxIcon.Error)


            End Try
        Else
            MsgBox("Este Correo no esta Registrado")
        End If
    End Sub

    Private Sub CambiarContrasena_Click(sender As Object, e As EventArgs) Handles CambiarContrasena.Click
        If NuevaContrasena.Text = RepitaContrasena.Text AndAlso CodigoConfirmacion.Text = CodigoContrasena Then
            If validarContrasena(NuevaContrasena.Text) = True Then
                MsgBox("Contraseña cambiada")
                'Dim SQL As String = "UPDATE TBL_Usuario_102 SET CP_CONTRASENA = '"
                Dim fkID As String = ConsultarID(CorreoUsuario)
                Insertar("UPDATE TBL_Usuario_102 SET CP_CONTRASENA = '" & NuevaContrasena.Text & "' " & "WHERE FK_ID_500 = '" & fkID & "'")
                Login.Show()
                Me.Close()

            Else
                MsgBox("Su contraseña debe contener:" & vbCrLf & "1. Mínimo 1 letra mayúscula" & vbCrLf & "2. Mínimo 1 letra minúscula" & vbCrLf & "3. Mínimo 1 número" & vbCrLf & "4. Entre 8 y 50 caracteres")
            End If

        Else
                MsgBox("Verifique su contraseña o código")
        End If

    End Sub

End Class