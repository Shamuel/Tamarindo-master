﻿Public Class Form6
    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        'Agregar codigo para traer información de la DB'
    End Sub

    Private Sub Form6_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.TextBox1.Enabled = False

    End Sub
End Class