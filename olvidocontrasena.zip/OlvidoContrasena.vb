﻿Public Class OlvidoContrasena
    Private Sub OlvidoContrasena_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label2.Visible = False
        Label3.Visible = False
        Label4.Visible = False
        NuevaContrasena.Visible = False
        RepitaContrasena.Visible = False
        CodigoConfirmacion.Visible = False
        CambiarContrasena.Visible = False
        IngreseCorreo.Visible = True
        EnviarCodigo.Visible = True
    End Sub

    Public CodigoContrasena As String
    Public CorreoUsuario As String
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles EnviarCodigo.Click
        Try
            CorreoUsuario = IngreseCorreo.Text
            Dim SmtpServer As New Net.Mail.SmtpClient()
            Dim mail As New Net.Mail.MailMessage()
            SmtpServer.UseDefaultCredentials = False
            SmtpServer.Credentials = New Net.NetworkCredential("proyecto1tamarindo@gmail.com", "sistemaHRtamarindo")
            SmtpServer.Port = 587
            SmtpServer.Host = "smtp.gmail.com"
            SmtpServer.EnableSsl = True
            SmtpServer.DeliveryMethod = Net.Mail.SmtpDeliveryMethod.Network
            mail = New Net.Mail.MailMessage()
            mail.From = New Net.Mail.MailAddress("proyecto1tamarindo@gmail.com")
            mail.To.Add(IngreseCorreo.Text)
            mail.Subject = "MailSubject"
            mail.Body = ""
            If mail.Body = "" Then
                Randomize()
                ' The program will generate a number from 0 to 50
                CodigoContrasena = Int(Rnd() * 123456789) + 9
                mail.Body = CodigoContrasena
            End If
            SmtpServer.Send(mail)
            IngreseCorreo.Clear()
            MsgBox("¡Código enviado con éxito!")
            Label2.Visible = True
            Label3.Visible = True
            Label4.Visible = True
            NuevaContrasena.Visible = True
            RepitaContrasena.Visible = True
            CodigoConfirmacion.Visible = True
            CambiarContrasena.Visible = True
            IngreseCorreo.Visible = False
            EnviarCodigo.Visible = False
        Catch ex As Exception
            MessageBox.Show("Error", "Error al enviar", MessageBoxButtons.OK, MessageBoxIcon.Error)


        End Try
    End Sub

    Private Sub CambiarContrasena_Click(sender As Object, e As EventArgs) Handles CambiarContrasena.Click
        IngreseCorreo.Text = ConsultarID(CorreoUsuario)
    End Sub

End Class