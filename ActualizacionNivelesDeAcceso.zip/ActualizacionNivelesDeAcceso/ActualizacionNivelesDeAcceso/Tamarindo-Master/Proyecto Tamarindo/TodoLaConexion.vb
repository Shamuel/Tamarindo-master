﻿Module TodoLaConexion
    '1- Definir nombre del servidor y la base de datos para conexion
    Public servidor_datos As String = "Data Source=LAPTOP-MIG91646;Initial Catalog=Tamarindo;Integrated Security=SSPI;"
    '2- Definir una conexion para la base de datos
    Public conexion As New SqlClient.SqlConnection(servidor_datos)
    Public instruccionSQL As SqlClient.SqlCommand
    Public Respuesta As SqlClient.SqlDataReader
    'sub para abrir conexion
    Sub abrirConexion()
        Try
            conexion.Open()

        Catch ex As Exception
            MsgBox("No se pudo Conectar")
        End Try


    End Sub
    'funcion para obtener usuarios de la BD
    Function UsuarioRegistrado(ByVal NombredeUsuario As String) As Boolean
        Dim ResultadoConexion As Boolean = False
        Try
            instruccionSQL = New SqlClient.SqlCommand("Select * from TBL_Usuario_102 where PK_IdUsuario='" & NombredeUsuario & "'", conexion)
            Respuesta = instruccionSQL.ExecuteReader

            If Respuesta.Read Then
                ResultadoConexion = True
            End If
            Respuesta.Close()

        Catch ex As Exception

        End Try
        Return ResultadoConexion
    End Function
    'funcion para obtener usuarios de la BD
    Function contrasena(ByVal NombredeUsuario As String) As String
        Dim ResultadoConexion As String = ""
        Try
            instruccionSQL = New SqlClient.SqlCommand("Select CP_Contrasena from TBL_Usuario_102 where PK_IdUsuario='" & NombredeUsuario & "'", conexion)
            Respuesta = instruccionSQL.ExecuteReader

            If Respuesta.Read Then
                ResultadoConexion = Respuesta.Item("CP_Contrasena")
            End If
            Respuesta.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return ResultadoConexion
    End Function

    Function Insertar(ByVal sql)
        instruccionSQL = New SqlClient.SqlCommand(sql, conexion)
        Dim i As Integer = instruccionSQL.ExecuteNonQuery
        If (i > 0) Then
            Return True
        Else
            Return False
        End If
    End Function

    Function InsertarPersona(ByVal sql)
        instruccionSQL = New SqlClient.SqlCommand(sql, conexion)
        Dim i As Integer = instruccionSQL.ExecuteNonQuery
        If (i > 0) Then
            Return True
        Else
            Return False
        End If

    End Function

    Function ConsultarID(ByVal CorreoUsuario As String) As String
        Dim ResultadoConexion As String = ""
        Try
            instruccionSQL = New SqlClient.SqlCommand("SELECT PK_ID FROM TBL_Persona_500 WHERE CP_Correo = '" & CorreoUsuario & "'", conexion)
            Respuesta = instruccionSQL.ExecuteReader

            If Respuesta.Read Then
                ResultadoConexion = Respuesta.Item("PK_ID")

            End If
            Respuesta.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return ResultadoConexion
    End Function

    Function validarContrasena(ByVal contraValida As String,
                               Optional ByVal caracMin As Integer = 8,
                               Optional ByVal caracMax As Integer = 50,
                               Optional ByVal minMayus As Integer = 1,
                               Optional ByVal minMinus As Integer = 1,
                               Optional ByVal minNumeros As Integer = 1) As Boolean
        Dim upper As New System.Text.RegularExpressions.Regex("[A-Z]")
        Dim lower As New System.Text.RegularExpressions.Regex("[a-z]")
        Dim number As New System.Text.RegularExpressions.Regex("[0-9]")

        If Len(contraValida) < caracMin Then Return False
        If Len(contraValida) > caracMax Then Return False
        If upper.Matches(contraValida).Count < minMayus Then Return False
        If lower.Matches(contraValida).Count < minMinus Then Return False
        If number.Matches(contraValida).Count < minNumeros Then Return False

        Return True
    End Function
    Function BloquearUsuarios(ByVal NombredeUsuario As String) As Integer
        Dim ResultadoConexion As Integer
        Try
            instruccionSQL = New SqlClient.SqlCommand("Select CP_Contador_CambioContrasena from TBL_Usuario_102 where PK_IdUsuario='" & NombredeUsuario & "'", conexion)
            Respuesta = instruccionSQL.ExecuteReader

            If Respuesta.Read Then
                ResultadoConexion = Respuesta.Item("CP_Contador_CambioContrasena")
            End If
            Respuesta.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return ResultadoConexion
    End Function

    Function TipoUsuario(ByVal ID As String) As Integer
        Dim ResultadoConexion As Integer
        Try
            instruccionSQL = New SqlClient.SqlCommand("Select FK_TipoUsuario_103 from TBL_Usuario_102 where PK_IdUsuario='" & ID & "'", conexion)
            Respuesta = instruccionSQL.ExecuteReader

            If Respuesta.Read Then
                ResultadoConexion = Respuesta.Item("FK_TipoUsuario_103")
            End If
            Respuesta.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
        Return ResultadoConexion
    End Function

    ' Function cambiarContraseña(ByVal ID As String, ByVal nuevaContrasena As String) As String
    'Dim ResultadoConexion As String = ""
    'Try
    '   instruccionSQL = New SqlClient.SqlCommand("UPDATE TBL_Usuario_102 SET CP_CONTRASENA = '" & nuevaContrasena & "'" & "WHERE FK_ID_500 ='" & ID & "'", conexion)
    '   Respuesta = instruccionSQL.ExecuteReader

    '  Catch ex As Exception
    '    MsgBox(ex.ToString)
    '  End Try

    'End Function

End Module
