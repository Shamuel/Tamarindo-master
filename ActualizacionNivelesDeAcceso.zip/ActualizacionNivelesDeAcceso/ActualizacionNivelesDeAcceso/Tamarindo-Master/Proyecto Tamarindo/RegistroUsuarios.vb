﻿Public Class Registro
    Private Sub Registro_Load(sender As Object, e As EventArgs) Handles MyBase.Load


    End Sub
    Public Contador As Integer = 3
    Private Sub Guardar_Click(sender As Object, e As EventArgs) Handles Guardar.Click
        Dim Agregar As String = "Insert into TBL_Usuario_102 values" & "('" & NombreDePersona.Text & "','" & Cedula.Text & "'," & TipodeUsuario.Text & ",'" & Contraseña.Text & "','" & FechaInclusion.Value.Date.ToString(" yyyy-MM-dd hh:mm") & "'," & 0 & ",'" & FechaInclusion.Value.Date.ToString(" yyyy-MM-dd hh:mm") & "'," & Contador & ")"


        If NombreDePersona.Text <> "" And Cedula.Text <> "" And RepetirContraseña.Text <> "" And Contraseña.Text <> "" Then
            If (RepetirContraseña.Text = Contraseña.Text) Then
                If validarContrasena(Contraseña.Text) = True Then
                    If (TodoLaConexion.Insertar(Agregar)) Then
                        MsgBox("Datos Guardados Correctamente")
                    Else
                        MsgBox("Error al guardar los datos")
                    End If

                    Cedula.Clear()
                    NombreDePersona.Clear()
                    Contraseña.Clear()
                    RepetirContraseña.Clear()
                    Login.Show()

                    Me.Close()




                Else
                    MsgBox("Su contraseña debe contener:" & vbCrLf & "1. Mínimo 1 letra mayúscula" & vbCrLf & "2. Mínimo 1 letra minúscula" & vbCrLf & "3. Mínimo 1 número" & vbCrLf & "4. Entre 8 y 50 caracteres")
                End If
            Else
                MsgBox("Las contraseñas no coinciden")
            End If

        Else
                MsgBox("Escriba en Cada Campo")
            End If


    End Sub

    Private Sub NombreDePersona_TextChanged(sender As Object, e As EventArgs) Handles NombreDePersona.TextChanged

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class