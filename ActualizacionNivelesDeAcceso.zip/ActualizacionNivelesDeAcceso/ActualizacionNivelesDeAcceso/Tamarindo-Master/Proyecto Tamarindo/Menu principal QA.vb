﻿Public Class Menu_principal_QA
    Private Sub ButtonExpedientes_Click(sender As Object, e As EventArgs) Handles ButtonExpedientes.Click

    End Sub

    Private Sub ButtonPruebas_Click(sender As Object, e As EventArgs) Handles ButtonPruebas.Click

    End Sub
End Class