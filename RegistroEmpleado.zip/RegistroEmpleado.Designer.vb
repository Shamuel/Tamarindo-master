﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RegistroEmpleado
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(RegistroEmpleado))
        Me.Salir = New System.Windows.Forms.Button()
        Me.Eliminar = New System.Windows.Forms.Button()
        Me.Guardar = New System.Windows.Forms.Button()
        Me.Modificar = New System.Windows.Forms.Button()
        Me.Nuevo = New System.Windows.Forms.Button()
        Me.Buscar = New System.Windows.Forms.Button()
        Me.TipoID = New System.Windows.Forms.ComboBox()
        Me.SegundoApellido = New System.Windows.Forms.TextBox()
        Me.PrimerApellido = New System.Windows.Forms.TextBox()
        Me.Nombre = New System.Windows.Forms.TextBox()
        Me.Cedula = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Fecha = New System.Windows.Forms.DateTimePicker()
        Me.Telefono = New System.Windows.Forms.TextBox()
        Me.Correo = New System.Windows.Forms.TextBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Salir
        '
        Me.Salir.BackColor = System.Drawing.Color.LimeGreen
        Me.Salir.Font = New System.Drawing.Font("Calibri", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Salir.ForeColor = System.Drawing.Color.White
        Me.Salir.Location = New System.Drawing.Point(625, 312)
        Me.Salir.Name = "Salir"
        Me.Salir.Size = New System.Drawing.Size(109, 50)
        Me.Salir.TabIndex = 55
        Me.Salir.Text = "Salir"
        Me.Salir.UseVisualStyleBackColor = False
        '
        'Eliminar
        '
        Me.Eliminar.BackColor = System.Drawing.Color.White
        Me.Eliminar.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Eliminar.ForeColor = System.Drawing.Color.LimeGreen
        Me.Eliminar.Location = New System.Drawing.Point(384, 400)
        Me.Eliminar.Name = "Eliminar"
        Me.Eliminar.Size = New System.Drawing.Size(93, 33)
        Me.Eliminar.TabIndex = 54
        Me.Eliminar.Text = "Eliminar"
        Me.Eliminar.UseVisualStyleBackColor = False
        '
        'Guardar
        '
        Me.Guardar.BackColor = System.Drawing.Color.White
        Me.Guardar.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guardar.ForeColor = System.Drawing.Color.LimeGreen
        Me.Guardar.Location = New System.Drawing.Point(257, 400)
        Me.Guardar.Name = "Guardar"
        Me.Guardar.Size = New System.Drawing.Size(93, 33)
        Me.Guardar.TabIndex = 53
        Me.Guardar.Text = "Guardar"
        Me.Guardar.UseVisualStyleBackColor = False
        '
        'Modificar
        '
        Me.Modificar.BackColor = System.Drawing.Color.White
        Me.Modificar.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Modificar.ForeColor = System.Drawing.Color.LimeGreen
        Me.Modificar.Location = New System.Drawing.Point(129, 400)
        Me.Modificar.Name = "Modificar"
        Me.Modificar.Size = New System.Drawing.Size(93, 33)
        Me.Modificar.TabIndex = 52
        Me.Modificar.Text = "Modificar"
        Me.Modificar.UseVisualStyleBackColor = False
        '
        'Nuevo
        '
        Me.Nuevo.BackColor = System.Drawing.Color.White
        Me.Nuevo.Font = New System.Drawing.Font("Calibri", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Nuevo.ForeColor = System.Drawing.Color.LimeGreen
        Me.Nuevo.Location = New System.Drawing.Point(12, 400)
        Me.Nuevo.Name = "Nuevo"
        Me.Nuevo.Size = New System.Drawing.Size(93, 33)
        Me.Nuevo.TabIndex = 51
        Me.Nuevo.Text = "Nuevo"
        Me.Nuevo.UseVisualStyleBackColor = False
        '
        'Buscar
        '
        Me.Buscar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Buscar.Location = New System.Drawing.Point(445, 21)
        Me.Buscar.Name = "Buscar"
        Me.Buscar.Size = New System.Drawing.Size(41, 24)
        Me.Buscar.TabIndex = 50
        Me.Buscar.Text = "."
        Me.Buscar.UseVisualStyleBackColor = True
        '
        'TipoID
        '
        Me.TipoID.FormattingEnabled = True
        Me.TipoID.Items.AddRange(New Object() {"San José", "Alajuela", "Cartago", "Heredia", "Guanacaste", "Puntarenas", "Limón", "", "", ""})
        Me.TipoID.Location = New System.Drawing.Point(203, 70)
        Me.TipoID.Name = "TipoID"
        Me.TipoID.Size = New System.Drawing.Size(211, 21)
        Me.TipoID.TabIndex = 49
        '
        'SegundoApellido
        '
        Me.SegundoApellido.Location = New System.Drawing.Point(203, 217)
        Me.SegundoApellido.Multiline = True
        Me.SegundoApellido.Name = "SegundoApellido"
        Me.SegundoApellido.Size = New System.Drawing.Size(211, 20)
        Me.SegundoApellido.TabIndex = 48
        '
        'PrimerApellido
        '
        Me.PrimerApellido.Location = New System.Drawing.Point(203, 168)
        Me.PrimerApellido.Multiline = True
        Me.PrimerApellido.Name = "PrimerApellido"
        Me.PrimerApellido.Size = New System.Drawing.Size(211, 21)
        Me.PrimerApellido.TabIndex = 47
        '
        'Nombre
        '
        Me.Nombre.Location = New System.Drawing.Point(203, 113)
        Me.Nombre.Multiline = True
        Me.Nombre.Name = "Nombre"
        Me.Nombre.Size = New System.Drawing.Size(211, 20)
        Me.Nombre.TabIndex = 46
        '
        'Cedula
        '
        Me.Cedula.Location = New System.Drawing.Point(203, 24)
        Me.Cedula.Multiline = True
        Me.Cedula.Name = "Cedula"
        Me.Cedula.Size = New System.Drawing.Size(211, 21)
        Me.Cedula.TabIndex = 45
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(19, 219)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(143, 18)
        Me.Label5.TabIndex = 44
        Me.Label5.Text = "Segundo Apellido:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(25, 171)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(127, 18)
        Me.Label4.TabIndex = 43
        Me.Label4.Text = "Primer Apellido:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(43, 115)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(73, 18)
        Me.Label3.TabIndex = 42
        Me.Label3.Text = "Nombre:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(48, 59)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(90, 18)
        Me.Label2.TabIndex = 41
        Me.Label2.Text = "Tipo de ID:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(52, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(65, 18)
        Me.Label1.TabIndex = 40
        Me.Label1.Text = "Cédula:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(611, 15)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(43, 16)
        Me.Label7.TabIndex = 39
        Me.Label7.Text = "Foto:"
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(565, 20)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(153, 139)
        Me.PictureBox1.TabIndex = 38
        Me.PictureBox1.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(41, 266)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(111, 16)
        Me.Label6.TabIndex = 36
        Me.Label6.Text = "Fecha Ingreso:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(52, 311)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(74, 16)
        Me.Label8.TabIndex = 56
        Me.Label8.Text = "Teléfono:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(19, 352)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(141, 16)
        Me.Label9.TabIndex = 57
        Me.Label9.Text = "Correo Electrónico:"
        '
        'Fecha
        '
        Me.Fecha.Location = New System.Drawing.Point(203, 262)
        Me.Fecha.Name = "Fecha"
        Me.Fecha.Size = New System.Drawing.Size(200, 20)
        Me.Fecha.TabIndex = 58
        '
        'Telefono
        '
        Me.Telefono.Location = New System.Drawing.Point(203, 307)
        Me.Telefono.Multiline = True
        Me.Telefono.Name = "Telefono"
        Me.Telefono.Size = New System.Drawing.Size(211, 20)
        Me.Telefono.TabIndex = 59
        '
        'Correo
        '
        Me.Correo.Location = New System.Drawing.Point(203, 351)
        Me.Correo.Multiline = True
        Me.Correo.Name = "Correo"
        Me.Correo.Size = New System.Drawing.Size(211, 20)
        Me.Correo.TabIndex = 60
        '
        'RegistroEmpleado
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(880, 455)
        Me.Controls.Add(Me.Correo)
        Me.Controls.Add(Me.Telefono)
        Me.Controls.Add(Me.Fecha)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Salir)
        Me.Controls.Add(Me.Eliminar)
        Me.Controls.Add(Me.Guardar)
        Me.Controls.Add(Me.Modificar)
        Me.Controls.Add(Me.Nuevo)
        Me.Controls.Add(Me.Buscar)
        Me.Controls.Add(Me.TipoID)
        Me.Controls.Add(Me.SegundoApellido)
        Me.Controls.Add(Me.PrimerApellido)
        Me.Controls.Add(Me.Nombre)
        Me.Controls.Add(Me.Cedula)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label6)
        Me.Name = "RegistroEmpleado"
        Me.Text = "RegistroEmpleado"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Salir As Button
    Friend WithEvents Eliminar As Button
    Friend WithEvents Guardar As Button
    Friend WithEvents Modificar As Button
    Friend WithEvents Nuevo As Button
    Friend WithEvents Buscar As Button
    Friend WithEvents TipoID As ComboBox
    Friend WithEvents SegundoApellido As TextBox
    Friend WithEvents PrimerApellido As TextBox
    Friend WithEvents Nombre As TextBox
    Friend WithEvents Cedula As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Fecha As DateTimePicker
    Friend WithEvents Telefono As TextBox
    Friend WithEvents Correo As TextBox
End Class
