﻿Public Class RegistroEmpleado


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Nuevo.Click

        Dim Agregar As String = "Insert into TBL_Persona_500 values" & "('" & Cedula.Text & "','" & TipoID.Text & "','" & Nombre.Text & "','" & PrimerApellido.Text & "','" & SegundoApellido.Text & "','" & Fecha.Value.Date.ToString(" yyyy-MM-dd hh:mm") & "','" & Telefono.Text & "','" & Correo.Text & "')"


        If Nombre.Text <> "" And Cedula.Text <> "" And PrimerApellido.Text <> "" And Correo.Text <> "" And SegundoApellido.Text <> "" Then

            If (TodoLaConexion.InsertarPersona(Agregar)) Then
                MsgBox("Datos Guardados Correctamente")
            Else
                MsgBox("Error al guardar los datos")
            End If

            Cedula.Clear()
            Nombre.Clear()
            Correo.Clear()
            Telefono.Clear()
            PrimerApellido.Clear()
            SegundoApellido.Clear()

        Else
            MsgBox("Escriba en Cada Campo")
        End If

    End Sub





    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Salir.Click
        Me.Close()
    End Sub

    Private Sub RegistroEmpleado_Load(sender As Object, e As EventArgs)

    End Sub

    Private Sub RegistroEmpleado_Load_1(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class