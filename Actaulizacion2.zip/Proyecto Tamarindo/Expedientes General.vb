﻿Public Class ExpedientesGeneral
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        BuscarExpedienteEmpleado.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        BuscarExpedienteCandidato.Show()
    End Sub
End Class