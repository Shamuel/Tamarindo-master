﻿Public Class Menú_principal_candidatos__empleados
    Private Sub ButtonSalir_Click(sender As Object, e As EventArgs) Handles ButtonSalir.Click
        Me.Close()

    End Sub

    Private Sub ButtonPruebas_Click(sender As Object, e As EventArgs) Handles ButtonPruebas.Click

    End Sub

    Private Sub ButtonExpediente_Click(sender As Object, e As EventArgs) Handles ButtonExpediente.Click
        ExpedienteDeEmpleado.Show()
    End Sub

    Private Sub Menú_principal_candidatos__empleados_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class